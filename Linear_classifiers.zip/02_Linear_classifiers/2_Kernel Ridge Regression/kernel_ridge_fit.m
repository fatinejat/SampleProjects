% 1. Create a function kernel_ridge_fit, which takes a matrix X ? Rn?m of 
%samples, a vector y ? Rn of outcomes for each sample, and a kernel function. 
%kernel_ridge_fit should return the estimated vector ? ? Rn and the mean 
%squared error on the training samples.

function [ alpha_vect, MSE ] = kernel_ridge_fit( X, y, ker, lambda)

K = create_kernel_matrix(X,ker);

dim = size(X);
alpha_vect = (K + (lambda * speye(dim(1))))\y;

MSE = mean_squared_error(alpha_vect, X,y,K);

end


