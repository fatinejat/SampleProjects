function [prediction] = get_prediction(alpha_vect,X,K,i)
dim = size(X);
prediction = 0;
for j = 1:dim(1)
     prediction = prediction + alpha_vect(j) * K(j,i);
end

end
