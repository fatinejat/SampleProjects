function [MSE] = mean_squared_error(alpha_vect, X, y, K)

dim = size(X);
MSE = 0;
for i = 1:dim(1)
    MSE = MSE + (y(i) - get_prediction(alpha_vect,X,K,i))^2;
end
MSE = MSE/dim(1);
end