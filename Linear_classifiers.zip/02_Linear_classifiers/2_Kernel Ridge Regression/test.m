function [  ] = test

% 3. a) Plot the mean squared training error of the first 100 samples obtained 
% from kernel_ridge_fit for ? ? {0.001, 0.01, 0.1, 1, 10, 20, 50, 100, 200,
% 500, 1000, 10000} and the following Kernel functions: linear, polynomial 
% (c = 1, d = 2), sigmoid (? = ?0.001, c = 1), and RBF (? = 0.001). The x 
% axis should denote the ? values in log scale and the y axis the mean squared
% error.

[X, Y] = read_csv;

lambda_vect = [0.001, 0.01, 0.1, 1, 10, 20, 50, 100, 200, 500, 1000, 10000];
log_lambda_vect = log(lambda_vect);

size_lambda_vect = size(lambda_vect);

plot_data_linear_kernel = zeros(size_lambda_vect(2),1);
plot_data_polynomial_kernel = zeros(size_lambda_vect(2),1);
plot_data_sigmoid_kernel = zeros(size_lambda_vect(2),1);
plot_data_rbf_kernel = zeros(size_lambda_vect(2),1);

alpha_vect_linear_kernel = zeros(size_lambda_vect(2), 100);
alpha_vect_polynomial_kernel = zeros(size_lambda_vect(2), 100);
alpha_vect_sigmoid_kernel = zeros(size_lambda_vect(2), 100);
alpha_vect_rbf_kernel = zeros(size_lambda_vect(2), 100);


for i=1:size_lambda_vect(2)
    [alpha_vect, MSE] = kernel_ridge_fit( X(1:100,:), Y(1:100,:), 'linear', lambda_vect(i));
    plot_data_linear_kernel (i,1) = MSE;
    alpha_vect_linear_kernel (i,:) = alpha_vect;
    
    [alpha_vect, MSE] = kernel_ridge_fit( X(1:100,:), Y(1:100,:), 'polynomial', lambda_vect(i));
    plot_data_polynomial_kernel (i,1) = MSE;
    alpha_vect_polynomial_kernel (i,:) = alpha_vect;
    
    [alpha_vect, MSE] = kernel_ridge_fit( X(1:100,:), Y(1:100,:), 'sigmoid', lambda_vect(i));
    plot_data_sigmoid_kernel (i,1) = MSE;
    alpha_vect_sigmoid_kernel (i,:) = alpha_vect;
    
    [alpha_vect, MSE] = kernel_ridge_fit( X(1:100,:), Y(1:100,:), 'rbf', lambda_vect(i));
    plot_data_rbf_kernel (i,1) = MSE;
    alpha_vect_rbf_kernel (i,:) = alpha_vect;
end

figure
plot(log_lambda_vect(1,:),plot_data_linear_kernel(:,1),'*')
title('Linear kernel')
xlabel('Log lambda')
ylabel('Mean squared error')
plot_data_linear_kernel(:,1);

figure
plot(log_lambda_vect(1,:),plot_data_polynomial_kernel(:,1),'*')
title('Polynomial kernel')
xlabel('Log lambda')
ylabel('Mean squared error')
plot_data_polynomial_kernel(:,1)

figure
plot(log_lambda_vect(1,:),plot_data_sigmoid_kernel(:,1),'*')
title('Sigmoid kernel')
xlabel('Log lambda')
ylabel('Mean squared error')
plot_data_sigmoid_kernel(:,1)

figure
plot(log_lambda_vect(1,:),plot_data_rbf_kernel(:,1),'*')
title('Rbf kernel')
xlabel('Log lambda')
ylabel('Mean squared error')
plot_data_rbf_kernel(:,1)


% 3.b)Use the remaining 97 samples to test all models trained above and plot 
% the mean squared test error obtained from kernel_ridge_predict. The x-axis 
% should denote the ? values in log scale and the y-axis the mean squared 
% error.

test_error_linear_kernel = zeros(size_lambda_vect(2),1);
test_error_polynomial_kernel = zeros(size_lambda_vect(2),1);
test_error_sigmoid_kernel = zeros(size_lambda_vect(2),1);
test_error_rbf_kernel = zeros(size_lambda_vect(2),1);

for i=1:size_lambda_vect(2)
    [ predict_vect, MSE] = kernel_ridge_predict(X(1:100,:), alpha_vect_linear_kernel(i,:), X(101:197,:), Y(101:197,:), 'linear');
    test_error_linear_kernel (i,1) = MSE;
    
    [ predict_vect, MSE] = kernel_ridge_predict(X(1:100,:), alpha_vect_polynomial_kernel(i,:), X(101:197,:), Y(101:197,:), 'polynomial');
    test_error_polynomial_kernel (i,1) = MSE;
    
    [ predict_vect, MSE ] = kernel_ridge_predict(X(1:100,:), alpha_vect_sigmoid_kernel(i,:), X(101:197,:), Y(101:197,:), 'sigmoid');
    test_error_sigmoid_kernel (i,1) = MSE;
    
    [ predict_vect, MSE ] = kernel_ridge_predict(X(1:100,:), alpha_vect_rbf_kernel(i,:), X(101:197,:), Y(101:197,:), 'rbf');
    test_error_rbf_kernel (i,1) = MSE;
end

figure
plot(log_lambda_vect(1,:),test_error_linear_kernel(:,1),'o')
title('Linear kernel (test data)')
xlabel('Log lambda')
ylabel('Mean squared error')
test_error_linear_kernel(:,1);

figure
plot(log_lambda_vect(1,:),test_error_sigmoid_kernel(:,1),'o')
title('Sigmoid kernel (test data)')
xlabel('Log lambda')
ylabel('Mean squared error')
test_error_sigmoid_kernel(:,1)

figure
plot(log_lambda_vect(1,:),test_error_rbf_kernel(:,1),'o')
title('Rbf kernel (test data)')
xlabel('Log lambda')
ylabel('Mean squared error')
test_error_rbf_kernel(:,1)

figure
plot(log_lambda_vect(1,:),test_error_polynomial_kernel(:,1),'o')
title('Polynomial kernel (test data)')
xlabel('Log lambda')
ylabel('Mean squared error')
test_error_polynomial_kernel(:,1)



end

