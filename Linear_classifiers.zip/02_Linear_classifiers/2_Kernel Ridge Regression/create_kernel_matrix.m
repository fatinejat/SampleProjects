function [ K ] = create_kernel_matrix( X, ker)

dim = size(X);
K = zeros(dim(1), dim(1));
for i = 1:dim(1)
    for j = 1:dim(1)
        K(i,j) = compute_kernel(ker, X(i,:), X(j,:));
    end
end


end

