function [ value ] = compute_kernel(ker,X,X2)

switch ker
    case 'linear'
            value = X * X2';
    case 'polynomial'
            value = (X * X2' + 1).^2;
    case 'rbf'
            value = exp(-0.001 * (norm(X-X2)^2));
    case 'sigmoid'
            value = tanh(-0.001 * X *X2' + 1);
    otherwise
        error(['Unsupported kernel ' ker])
end

end

