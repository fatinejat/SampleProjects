% 2. Create a function kernel_ridge_predict, which takes the matrix X used 
% during training, the vector ?, a matrix Xt of samples for testing and their 
% respective outcomes yt, and a kernel function. The function should return 
% a vector of predicted outcomes and the mean squared error on the testing 
% samples.

function [ predict_vect, MSE ] = kernel_ridge_predict( X, alpha_vect, Xt, yt, ker)
dim = size(X);
dim_yt = size(yt);
predict_vect = zeros(dim_yt(1));

for i=1:dim_yt(1)
    for j=1:dim(1)
        predict_vect(i) = predict_vect(i) + alpha_vect(j) * compute_kernel(ker, X(j,:), Xt(i,:));
    end
end
    
MSE = 0;
for i = 1:dim_yt(1)
    MSE = MSE + (yt(i) - predict_vect(i))^2;
end
MSE = MSE/dim_yt(1);

end

