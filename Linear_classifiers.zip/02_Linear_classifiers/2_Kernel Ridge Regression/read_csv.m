function [X, Y] = read_csv
% Apply your implementation of kernel ridge regression to the Aqua-all.csv 
% data set. The first column denotes the outcome y, the remaining columns 
% the features
M = csvread('Aqua-all.csv',0,0);
dim = size (M);
X = M(:,2:dim(2));
Y = M(:,1);

end

