function [ beta ] = olsfit( X , Y)
    dim_X = size(X);
    X_with_intercept = [ones(dim_X(1),1) X];
    beta = lscov(X_with_intercept,Y);
end

