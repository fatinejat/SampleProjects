function [X, Y] = read_csv

M = csvread('bodyfat.csv',1,0);
dim = size (M);
X = M(:,2:dim(2));
Y = M(:,1);

end

