function [ ] = test

[X,Y] = read_csv;

%2. Create multiple models that predict the amount of body fat based on one of the features mentioned above, respectively. For each model create a scatter plot which depicts the data and the model.
for i = 1:14
  feat_vect = X(:, i);
  linear_regression(feat_vect, Y);
end

%3. Create a single model that contains all of the features mentioned above
b = olsfit(X,Y)
max = -100;
min = 100;
for i = 2:14
    if max < b(i)
        max = b(i);
        max_i = i;
    end
    
    if min > b(i)
        min = b(i);
        min_i = i;
    end
end

%3. Which features have the highest/lowest coefficients
max_i % is the 8th feature (hip)
min_i % is the 6th feature (chest)
end

function [] = linear_regression(feat_vect, body_fat_vect)
b = olsfit(feat_vect,body_fat_vect);
y = b(1) + b(2)*feat_vect;

figure
plot(feat_vect,y,feat_vect,body_fat_vect,'ro');

end


