function [ intra_plot_data ] = getIntraClusteringVar(D, overall_mean)
% returns inter-custering/intra-clustering variance for different number of
% clusters
%let's assume the the max number of clusters is 20
intra_plot_data = zeros(20,1);
for i=1:20
    [IDX,C] = kmeans(D,i+1);
    intra = getIntraClusteringVariation(D,IDX,C);
    total = getTotalClusteringVariation(D,overall_mean);
    intra_plot_data(i) = intra/total;
end


end

function [intra_var] = getIntraClusteringVariation(X,INX,C)
% formula taken from http://en.wikipedia.org/wiki/F-test (within-group variability)
intra_var = 0;
n = size(X,1);
for i = 1:n
    intra_var = intra_var + (X(i,:)-C(INX(i),:))*(X(i,:)-C(INX(i),:))';
end
intra_var = intra_var/(n-max(INX));
end

function [total_var] = getTotalClusteringVariation(X,overall_mean)
total_var = 0;
n = size(X,1);
for i = 1:n
    total_var = total_var + (X(i,:)'-overall_mean)'*(X(i,:)'-overall_mean);
end
total_var = total_var/(n-1);
end

