function [ count ] = degug( X )
count = 0;
for i=1:size(X,1)
    if(X(i,i)<0.001)
        count = count +1;
    end
end

