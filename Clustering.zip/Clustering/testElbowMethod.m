DP = csvread('data2.csv');
overall_mean_t = mean(DP');
[intra_plot_data] = getIntraClusteringVar(DP',overall_mean_t');

% after multiple runs, the optimum seems to be 8 or 9 clusters
plot (2:size(intra_plot_data,1)+1,intra_plot_data,'-' );
xlabel('Number of clusters')
ylabel('Intra cluster variance / Total variance')

