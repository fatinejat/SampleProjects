D = csvread('data3.csv');

y = randsample(size(D,2),2);
[data, parameters, steps] = EM(D,2, y, false);

fprintf('First gaussian has mu = ');
parameters(1).mu
fprintf('First gaussian has sigma = ');
parameters(1).sigma
fprintf('Second gaussian has mu = ');
parameters(2).mu
fprintf('Second gaussian has sigma = ');
parameters(2).sigma
fprintf('Converged in %d steps', steps);
% if the data is the result of pca, the variables shoul be uncorelated,
% therefore the initial cov matrix will only have non-zero values on the
% diagonal

[data2, parameters2, steps2] = EM(D,2, y, true);

fprintf('PCA First gaussian has mu = ');
parameters2(1).mu
fprintf('PCA First gaussian has sigma = ');
parameters2(1).sigma
fprintf('PCA Second gaussian has mu = ');
parameters2(2).mu
fprintf('PCA Second gaussian has sigma = ');
parameters2(2).sigma
fprintf('Converged in %d steps', steps2);