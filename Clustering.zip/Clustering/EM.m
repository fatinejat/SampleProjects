function [ data, parameters, steps ] = EM(D, k, y, pca)
% D - data point matrix
% k - number of clusters
% pca - the data is the result of pca
% y - initial mean values

N = size(D,2);
data = repmat(struct('gamma_vect',zeros(k,1)),N,1);

%initialization of parameters
C = cov(D');
if(pca ==true)
    for i=1:size(C,1)
         for j=1:size(C,2)
             if(i~=j)
                 C(i,j) = 0;
             end
         end
    end
end
parameters = repmat(struct('weight',1/k,'mu',zeros(size(D,1),1),'sigma',C),k,1);

for i=1:k
    parameters(i).mu = D(:,y(i));
end

%EM algorithm
converged = false;
old_llk = loglikelihood(D, parameters,k);
steps = 0;
while (~converged)
    steps = steps + 1;
    
    %1. E step
    for i = 1:N
        data(i).gamma_vect = computeMembership(D(:,i), k, parameters);
    end
    
    %2. M step
    new_parameters = computeParameters(D, k, data, parameters);
    new_llk = loglikelihood(D, new_parameters,k);
    
    %3. Check convergence
    converged = checkConvergence(parameters, new_parameters, k, old_llk, new_llk);
    
    parameters = new_parameters;
    old_llk = new_llk;
    
end

end



function [gamma_vect]=computeMembership(x,k, parameters)
% returns the membership values for every class for the data point x

gamma_vect = zeros(k,1);
for j=1:k
    s = 0;
    for l = 1:k
        s = s + parameters(l).weight * mvnpdf(x, parameters(l).mu, parameters(l).sigma);
    end
    
    %debug
    if(s == 0)
        fprintf('');
    end
    
    if(s ~= 0) % not an outliar
        gamma_vect(j) = parameters(j).weight * mvnpdf(x', parameters(j).mu', parameters(j).sigma)/s;
    end
end

end

function [parameters]=computeParameters(X, k, data, parameters)
% returns the newly computed weights, means and covariance matrices

N = size(X,2);
for j = 1:k
    for i = 1:N
        gamma = data(i).gamma_vect(j);   
        parameters(j).weight = parameters(j).weight + gamma;
        parameters(j).mu = parameters(j).mu + (gamma * X(:,i));
    end
    parameters(j).weight = parameters(j).weight / N;
    parameters(j).mu = parameters(j).mu / (N * parameters(j).weight);
    
    for i = 1:N
        M = (X(:,i) - parameters(j).mu)*(X(:,i) - parameters(j).mu)';
        parameters(j).sigma = parameters(j).sigma + data(i).gamma_vect(j)* M;
    end
  
    parameters(j).sigma = parameters(j).sigma / (N * parameters(j).weight);
end

end

function [converged] = checkConvergence(parameters, new_parameters, k, old_llk, new_llk)
paramChanged = false;
% check first if at least one of parameters changed
for i=1:k
    if(abs(parameters(i).weight - new_parameters(i).weight) > 0.001 || norm(parameters(i).mu - new_parameters(i).mu) > 0.001 || ~isequal(parameters(i).sigma, new_parameters(i).sigma)) %TODO:find a better way to compare matrices
        paramChanged = true;
    end  
end
llkChanged = new_llk - old_llk > 0.01;

% if llk or the parameters didn't changed then we end the alg
converged = (~llkChanged) || (~paramChanged);
end

function [llk] = loglikelihood(X, parameters,k)
llk = 0;
for i = 1:size(X,2)
    s=0;
    for j =1:k
        f = mvnpdf(X(:,i), parameters(j).mu, parameters(j).sigma);
        s = s + parameters(j).weight * f;
    end
    llk = llk + log(s);
end
end
