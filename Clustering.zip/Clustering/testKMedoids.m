D = csvread('data1.csv');
data = KMedoids(D,3);
[Y] = mdscale(D,2);
scatter(Y(:,1), Y(:,2), 100, extractfield(data,'cluster'));


