from Tkinter import  *
from ttk import *
    
from  GUI.Interface import *

    
class ListPopup:
    """**Wrapper for the tk.Listbox class that displays a popup and allows to get the selected value**"""
    
    def __init__(self,  list,  msg):
        """Constructor
        
        Input:
        
        - *list* (list of strings): list to display and choose from
        - *msg* (string): message displayed as title of the popup
        
        """
        self.selection=0
        self.root=Tk()
        self.root.title(msg)
        self.list= Listbox ( self.root)
        for line in list:
            self.list.insert ( END, line )
        self.list.grid(row=0,  column=0)
        self.list.selection_set(first=0)
        self.list.bind("<Double-Button-1>", self.get_selection)
        okButton = Button(self.root,  text="OK", command=self.get_selection)
        okButton.grid(row=1,  column=0)
        warning=Label(self.root,  text="Please select one element")
        warning.grid(row=2,  column=0)
        self.root.mainloop()
        
    def get_selection(self, *args):
        """ destroys the popup and stores the selected value in self.selection"""
        self.selection=self.list.curselection()
        self.root.quit()
        self.root.destroy()
        
    
def display_popup(msg=''):
    root=Tk()
    label=Label(root,  text=msg)
    label.grid(row=0,  column=0)
    okButton = Button(root,  text="OK", command=root.destroy)
    okButton.grid(row=1,  column=0)

def show2im(im1, im2):
    root = Tk()
    Interface(root, CTIm=ImageW(img=im1),  PETIm=ImageW(img=im2) )
    root.mainloop()
    root.destroy()
