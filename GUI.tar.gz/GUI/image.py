import numpy
import matplotlib.pyplot as plt
from scipy import ndimage,  optimize
from math import exp,  log,  fabs


import sys
sys.path.append('/home/mbieth/Dropbox/TUM/Code/python/')
from GUI import io_operations
from GUI import user_interaction
from GUI import misc

class ImageW:
    """**Wrapper class for handling 3D images**
    
    Members 
    
    - *img* (ndarray): data
    - *min* (float): min value in the image
    - *max* (float): max value in the image
    - *metadata* (dict): metadata of the image
    """
    
    def __init__(self , path='',  size=(1,   1,   1),  value=1,  img=None,  datatype='int8',  metadata={},  metadata_last={}):
        """Constructor 
        
        - reads an image from a file if given, 
        - otherwise makes a copy of an image if *img* is given, 
        - otherwise creates an image of the given size (default (1,1,1)) and uniform value (default 1)"""
        self.metadata={}
        self.metadata_last={}
        if len(path)>0:
            self.img=io_operations.read_file(path)
            if not isinstance(self.img,  numpy.ndarray):
                #there is metadata in the file. where is the image?
                im,  meta1,  meta_l=self.img
                self.img=im
                self.metadata.update(meta1)
                self.metadata_last.update(meta_l)
                try:
                    self.img=self.metadata['RescaleSlope']*self.img+self.metadata['RescaleIntercept']
                    self.metadata['RescaleSlope']=1
                    self.metadata['RescaleIntercept']=0
                    self.metadata_last['RescaleSlope']=1
                    self.metadata_last['RescaleIntercept']=0
                except KeyError:
                    pass
        elif not (img is None):
            self.img=img
        else :
            self.img=numpy.ndarray(shape=size,  dtype=datatype)
            self.img[:, :, :]=value
        self.metadata.update(metadata)
        self.metadata_last.update(metadata_last)
        self.max=self.img.max()
        self.min=self.img.min()
        
 
    def size(self):
        """Outputs:
       
        - tuple: the size of the image"""
        return self.img.shape
    
    def size_2d(self, axis):
        
        if axis == 0:
            return (self.img.shape[1],self.img.shape[2])
        if axis == 1:
            return (self.img.shape[0],self.img.shape[2])
        if axis == 2:
            return (self.img.shape[0],self.img.shape[1])
        
    def get_slice(self,  axis = 0, index = 1):
        """returns  a slice indexed by 'index' in a certain dimension ('axis')
        
        Inputs:
        
        - *axis* (int): operating dimension
        - *index* (int): slice number
        
        Outputs:
        
        - numpy array. slice number z of the image
        """
        if axis == 0:
            return self.img[index, :, :].squeeze()
        elif axis == 1:
            return self.img[:, index, :].squeeze()
        elif axis == 2:
            return self.img[:, :, index].squeeze()
 
    def show_slice(self, axis = 0, index = 1):
        """displays  a slice indexed by 'index' in a certain dimension ('axis')
        
        Inputs:
        
        - *axis* (int): operating dimension
        - *index* (int): slice number
        
        """
        slice=self.get_slice(axis, index)
        plt.imshow(slice)
        plt.show()
        
    def mask(self):
        """computes mask of the filled biggest connected component of the image.
        If used on a CT image, it will return the mask of the body of the patient
        
        Outputs:
        
        - numpy array (size of the image): mask of the body for a CT image
        
        """
        im=numpy.array(self.img-self.min)
        im[im<0.15*(self.max-self.min)]=0
        m=im>0
        label_im, nb_labels=ndimage.label(m)
        sizes = ndimage.sum(m, label_im, range(nb_labels + 1))
        L=sizes.argmax()
        mas=numpy.array(label_im==L,  dtype=int)
        #fill the holes slice by slice
        for z in range(0,  im.shape[2]):
            mas[:, :, z]=ndimage.morphology.binary_fill_holes(mas[:, :, z])
        return mas.astype(numpy.bool)
        
        
    def compute_SUV(self):
        """computes the SUV supposing that the image is a PET image
        
        Outputs:
        
        -ImageW: the SUV image including the metadata
        
        """
        try:
            if self.metadata['DecayCorrection'] == 'START':
                dt=misc.time2sec(self.metadata['AcquisitionTime'])-GUI.misc.time2sec(self.metadata['RadiopharmaceuticalInformationSequence']['RadiopharmaceuticalStartTime'])
                corr=1/exp(-dt*log(2)/float(self.metadata['RadiopharmaceuticalInformationSequence']['RadionuclideHalfLife']))
                factor=corr*self.metadata['PatientWeight']*1000/float(self.metadata['RadiopharmaceuticalInformationSequence']['RadionuclideTotalDose'])
                return ImageW(img=self.img*factor,  metadata=self.metadata)
            elif self.metadata['DecayCorrection'] == 'ADMIN':
                factor=self.metadata['PatientWeight']*1000/float(self.metadata['RadiopharmaceuticalInformationSequence']['RadionuclideTotalDose'])
                return ImageW(img=self.img*factor,  metadata=self.metadata)
            else:
                raise AttributeError('Decay correction method unknown')
        except KeyError:
            user_interaction.display_popup(msg='Some metadata is missing, please open a valid PET image')
        
    def align(self,  image):
        """aligns the image to an other one either by resampling or using the metadata if present
        using http://nipy.org/nibabel/dicom/dicom_orientation.html
        
        Inputs:
        
        - *image* (ImageW): image to align to
        """
        try:
            #calculate affine from image to real space
            A1=numpy.zeros(shape=(4, 4))
            A1[3, 3]=1
            dr1=image.metadata['PixelSpacing'][1]
            dc1=image.metadata['PixelSpacing'][0]
            F1=numpy.zeros(shape=(3, 2))
            F1[:, 0]=image.metadata['ImageOrientationPatient'][3:6]
            F1[:, 1]=image.metadata['ImageOrientationPatient'][0:3]
            A1[0:3, 0]=F1[:, 0]*dr1
            A1[0:3, 1]=F1[:, 1]*dc1
            A1[0:3, 2]=(image.metadata['ImagePositionPatient']-image.metadata_last['ImagePositionPatient'])/(1-image.size()[2])
            A1[0:3, 3]=image.metadata['ImagePositionPatient']
            
            #calculate affine from self to real space
            A2=numpy.zeros(shape=(4, 4))
            A2[3, 3]=1
            dr2=self.metadata['PixelSpacing'][1]
            dc2=self.metadata['PixelSpacing'][0]
            F2=numpy.zeros(shape=(3, 2))
            F2[:, 0]=self.metadata['ImageOrientationPatient'][3:6]
            F2[:, 1]=self.metadata['ImageOrientationPatient'][0:3]
            A2[0:3, 0]=F2[:, 0]*dr2
            A2[0:3, 1]=F2[:, 1]*dc2
            A2[0:3, 2]=(self.metadata['ImagePositionPatient']-self.metadata_last['ImagePositionPatient'])/(1-image.size()[2])
            A2[0:3, 3]=self.metadata['ImagePositionPatient']
            
            T1=numpy.linalg.inv(A1).dot(A2)
            T1=numpy.linalg.inv(T1)
            im=ndimage.interpolation.affine_transform(self.img,  T1[0:3,  0:3],  offset= T1[0:3, 3],  output_shape=image.size())
            self.img=im
            
            self.metadata['PixelSpacing']=image.metadata['PixelSpacing']
            self.metadata_last['PixelSpacing']=image.metadata['PixelSpacing']
            self.metadata['ImageOrientationPatient']=image.metadata['ImageOrientationPatient']
            self.metadata_last['ImageOrientationPatient']=image.metadata['ImageOrientationPatient']
            self.metadata['ImagePositionPatient']=image.metadata['ImagePositionPatient']
            self.metadata_last['ImagePositionPatient']=image.metadata['ImagePositionPatient']
            
        except KeyError:
            self.img=ndimage.interpolation.zoom(self.img,  zoom=(image.size()[0]/self.size()[0],  image.size()[1]/self.size()[1],  image.size()[2]/self.size()[2]))
        
    def bone_mask(self,  ed=True):
        """computes the masks of the bones from a CT image
        
        Outputs:
        
        - numpy array (size of the image): mask of the bones in the image (if it is a CT)
        """
        mask=self.mask()
        im=numpy.array(self.img)
        im=im.astype(numpy.float32)
        
        im[mask==0]=self.min
        
        Nbins=2000
        h1, b1=numpy.histogram(im[im>(self.min+1024)],  bins=Nbins)
        c1=(b1[0:Nbins]+b1[1:(Nbins+1)])/2
        i1=numpy.argmax(h1)
        h2, b2=numpy.histogram(im[(im>(self.min+0.10*(self.max-self.min)))&(im<(self.min+1024))],  bins=Nbins)
        c2=(b2[0:Nbins]+b2[1:(Nbins+1)])/2
        i2=numpy.argmax(h2)
        
        Ai=[h2[i2],  c2[i2],  30,  h1[i1],  c1[i1],  30]
        h2, b2=numpy.histogram(im[im>(self.min+0.10*(self.max-self.min))],  bins=Nbins)
        c2=(b2[0:Nbins]+b2[1:(Nbins+1)])/2
        A,  cov=optimize.curve_fit(misc.gaussian_mixture,  xdata=c2, ydata= h2,  p0=Ai)

        if A[4]<A[1]:
            a=A[0:3]
            A[0:3]=A[3:6]
            A[3:6]=a
        HT=A[4]+2*fabs(A[5])
        #HT=max(HT, 220)
        
        im[im<((self.min+900)*mask)]=self.min+900
        bones=im>HT
        
        me=numpy.get_mean(im[bones])
        st=numpy.std(im[bones])
        del  h1,  h2,  b1,  b2,  c1,  c2,  Nbins
        
        #do chunk by chunk, otherwise the memory is not manageable
        step=150
        for z in range(0,  self.size()[2],  step):
            print('chunk starting at '+str(z))
            zt=min(z+step,  self.size()[2])
            bones[:, :, z:zt]=misc.bone_reg(im[:, :, z:zt],  mask[:, :, z:zt],  HT,  me,  st,  self.metadata)
        
        #clean up
        u=numpy.ones(shape=(3, 3, 3))
        bones=ndimage.morphology.binary_closing(bones,structure=u)
        label_im, nb_labels=ndimage.label(bones)
        for l in range(nb_labels):
            if numpy.sum(label_im==l)<25:
                bones[label_im==l]=0

        return bones
        
