import scipy.io
import h5py
import SimpleITK as itk
from lxml import etree
import os
import dicom
import hdf5storage
import pickle

from GUI import user_interaction
from GUI.misc import *

from IO import own_itk as oitk

def get_data_from_mat(file=''):
    """
    reads mat files. calls the hdf5 function if the file is v7.3
    
     Inputs:
    
    - *file* (string): file to read
    """
    if len(file)>0:
        data={}
        if file[(len(file)-4):(len(file))]!='.mat':
            raise ImportError("This should be a .mat file")
        mat=scipy.io.loadmat(file)
        count =0
        for key in mat.keys():
            if key[0]!='_':
                count+=1
                data[key] = mat[key]
        if count==1:
            data=data[list(data.keys())[0]]
        return data

def get_data_from_hdf5(file=''):
    '''
    reads hdf5 files
    
    Inputs:
    
    - *file* (string): file to read'''
    if len(file)>0:
            if (file[(len(file)-4):(len(file))]!='.mat')&(file[(len(file)-3):(len(file))]!='.h5'):
                raise ImportError("This should be a .mat or .h5 file")
            data={}
            h5=h5py.File(file, 'r')
            count =0
            for key in h5.keys():
                count+=1
                data[key]=get_data_from_hdf5_group(h5[key])
            if count==1:
                data=data[list(data.keys())[0]]
            return data
            
def get_data_from_hdf5_group(group):
    """recursively converts hdf5 groups to dictionnaries
        !!!!CAREFULL: all uint16 are converting to strings!!!
        
        Input:
        
        - *group* (hdf5 group or dataset): group to be converted
    """
    if  isinstance(group, h5py._hl.group.Group):
        data={}
        for name in group:
            data[name]=get_data_from_hdf5_group(group[name])
    else:
        #careful, hdf5 stores the dimensions in reversed order
        data=numpy.transpose(group.value)
        if data.shape==(1, 1):
            data=data[0, 0]
        elif group.dtype is numpy.dtype('uint16'):
            data=group.value.tostring().decode("utf-8").replace('\x00','')
    return data
    

def read_both_file(file=''):
    """
    reads a file by finding its format using its extension
    
    Inputs:
    
    - *file* (string): file to read
    
    Outputs:
    
    -the content of the file as dictionnary or numpy array
    
    """
    if len(file)>0:
        if file[(len(file)-3):(len(file))]=='.h5':
            return get_data_from_hdf5(file)
        elif file[(len(file)-4):(len(file))]=='.mat':
            try:
                return get_data_from_mat(file)
            except NotImplementedError:
                return get_data_from_hdf5(file)
        elif file[len(file)-11:len(file)] == 'CONTENT.XML':
            source_base_time,  patient_id,  request_id,  modality1=choose_dicom_series_sectra(file)
            im1,  meta1,  meta1l= read_dicom(source_base_time)
            source_base_time,  patient_id,  request_id,  modality2=choose_dicom_series_sectra(file,  patient_id=patient_id, request_id=request_id )
            im2,  meta2,  meta2l= read_dicom(source_base_time)
            if (modality1=='CT')&(modality2=='PET'):
                return im1, meta1, meta1l,   im2,  meta2,  meta2l
            elif (modality1=='PET')&(modality2=='CT'):
                return im2, meta2, meta2l,  im1,  meta1,  meta1l
            else:
                raise TypeError('Please choose one PET and one CT image')
        else:
            raise NotImplementedError('This format is not supported')


def choose_dicom_series_sectra(source_base,  patient_id='', request_id='' ):
    '''
    Helps the user to choose a serie based on the SECTRA .xml file
    
    Inputs:
    
    - *source_base* (string): base directory of the DICOM file tree
    - *patient_id* (string): patient id if known
    - *request_id* (string): request id if known
    
    Outputs:
    
    - the folder where the chosen serie is to be found
    '''
    
    if (source_base[-1] != '/')&(source_base[len(source_base)-4:len(source_base)]!='.XML'):
        source_base = source_base+'/'
    
    if source_base[len(source_base)-11:len(source_base)]!='CONTENT.XML':
        somexmlurl = source_base+'SECTRA/CONTENT.XML'
    else:
        somexmlurl = source_base
    
    
    tree = etree.parse(somexmlurl)
    root = tree.getroot()
    
    if len(patient_id)==0:
        nbOfPatients = len(root.findall('patient'))
        #print ('DICOM database consists of '+str(nbOfPatients)+' patients')
        
        #choose a patient
        if nbOfPatients>1:
            patients=[]
            n=0
            for p in root.iter('patient'):
                patients[n] = p.get('id')
                patients[n] = patients[n]+' '+p.find('patient_data').find('personal_id').text
                birth_year = p.find('patient_data').find('name').text
                birth_year = birth_year[-4:]
                if not numpy.all([i.isdigit() for i in birth_year]):
                    birth_year = '?'
                elif (birth_year[0:2] != '19') and (birth_year[0:2] != '20'): 
                    birth_year = '?'
                patients[n]= patients[n]+' '+birth_year
                n=n+1
            patientChoice=user_interaction.ListPopup(patients,  msg="Please choose a patient")
            nPatient=patientChoice.selection [0]   
        else:
            nPatient=0
        patient=root.findall('patient')[nPatient]
        patient_id = patient.get('id')  
    else:
        for p in root.iter('patient'):
            if p.get('id')==patient_id:
                patient=p
    
    if len(request_id)==0:
        #choose a timepoint 
        nbOfTimePoints = len(patient.findall('request'))
        #print (str(nbOfTimePoints)+' study time points are found')
        if nbOfTimePoints>1:
            dates=[req.find('study').find('study_data').find('datetime').text for req in patient.iter('request')]
            TimePointChoice=user_interaction.ListPopup(dates,  msg="Please choose a time point")
            TimePoint=TimePointChoice.selection[0]
        else:
            TimePoint=0
        request=patient.findall('request')[TimePoint]
        request_id = request.get('id')
    else:
        for r in patient.iter('request'):
            if r.get('id')==request_id:
                request=r
    
    nbStudies=len(request.findall('study'))
    if nbStudies>1:
        studies=[study.get('id') for study in request.iter('study')]
        StudyChoice=user_interaction.ListPopup(studies,  msg="Please choose a study")
        Study=StudyChoice.selection[0]
    else:
        Study=0
    study=request.findall('study')[Study]
    study_id = study.get('id')
    
    nbSeries=len(study.findall('series'))
    if nbSeries>1:
        series=[serie.find('series_data').find('description').text for serie in study.iter('series')]
        SerieChoice=user_interaction.ListPopup(series,  msg="Please choose a serie")
        Serie=SerieChoice.selection[0]
    else:
        Serie=0
    descr=study.findall('series')[Serie].find('series_data').find('description').text
    if descr.find('PET')>-1:
        modality='PET'
    else:
        modality='CT'
    serie=study.findall('series')[Serie]
    serie_id = serie.get('id')
            
                    
    source_base_time = source_base[0:len(source_base)-18]+'DICOM/'+patient_id+'/'+request_id+'/'+study_id+'/'+serie_id+'/'
                    
                    
    return source_base_time,  patient_id,  request_id,  modality
    
def read_dicom(path, verbose=False):
    '''
    reads dicom series.

    Inputs:
     
    - *path* (string): path to dicom series.
    - *verbose* (boolean):  print out all series file names.

    Outputs:
     
    - *image* (numpy array): image volume.
    '''
    #get image
    reader = itk.ImageSeriesReader()
    reader.SetOutputPixelType(itk.sitkVectorFloat32)
    names = reader.GetGDCMSeriesFileNames(path)
    if len(names) < 1:
        raise IOError('No Series can be found at the specified path!')
    elif verbose:
        print ('image series found in %s:\n\t' % path,)
    reader.SetFileNames(names)
    image = reader.Execute()
    if verbose:
        print ('read image with size', [x for x in image.GetSize()])
    #get metadata
    ds1 = dicom_meta_to_dict(dicom.read_file(names[0]))
    ds2 = dicom_meta_to_dict(dicom.read_file(names[len(names)-1]))
    
    return numpy.transpose(itk.GetArrayFromImage(image)),  ds1,  ds2
   
def dicom_meta_to_dict(meta):
    dict={}
    if isinstance(meta,  dicom.dataset.Dataset):
        for field in meta.dir():
            if (field!='PixelData') & (meta.data_element(field) is not None):
                dict[field]=dicom_meta_to_dict(meta.data_element(field).value)
        return dict
    elif isinstance(meta,  dicom.sequence.Sequence):
        return dicom_meta_to_dict(meta[0])
    elif isinstance(meta, dicom.multival.MultiValue ):
        list=[]
        for i in range(0,  len(meta)):
            if isfloat(meta[i]):
                list.append( float(meta[i]))
            else:
                list.append( meta[i])
        return numpy.asarray(list)
    else:
        return meta
    
def read_file(file=''):
    """
    reads a file by finding its format using its extension
    
    Inputs:
    
    - *file* (string): file to read
    
    Outputs:
    
    -the content of the file as dictionnary or numpy array
    
    """
    if len(file)>0:
        if file[(len(file)-3):(len(file))]=='.h5':
            return get_data_from_hdf5(file)
        elif file[(len(file)-4):(len(file))]=='.mat':
            try:
                return get_data_from_mat(file)
            except NotImplementedError:
                return get_data_from_hdf5(file)
        elif file[(len(file)-4):(len(file))]=='.nii' or \
                file[(len(file)-4):(len(file))]=='.mhd' or \
                file[(len(file)-4):(len(file))]=='.png' or \
                file[(len(file)-4):(len(file))]=='.tiff':
            return oitk.getItkImageArray(file)
        elif file[len(file)-11:len(file)] == 'CONTENT.XML':
            source_base_time,  patient_id,  request_id,  modality=choose_dicom_series_sectra(file)
            return read_dicom(source_base_time)
        else:
            raise NotImplementedError('This format is not supported')

def write_mat(data,  file_name,  variable_name=''):
    """writes a matlab file (up to version 7.2)
    
    Inputs:
    - *data* (dict or ndarray): data to save
    - *file_name (string) : path to the file
    - *variable_name* (string): if *data* is not a dictionnary, it is save with *variable_name* as a name in the matlab structure
    """
    if (compute_size(data)<2**32) and not(contains_bool(data)):
        #data is compatible with matlab v5 format
        if isinstance(data, dict):
            scipy.io.savemat(file_name,  data)
        else:
            dico={}
            if len(variable_name)>0:
                dico[variable_name]=data
            else:
                dico['data']=data
            scipy.io.savemat(file_name,  dico)
    else:
        write_hdf5(data,  file_name,  variable_name)
        
def write_pickle(data, file_name):        
    
    with open(file_name, 'w') as f:
        pickle.dump(data, f)
        
def write_hdf5(data,  file_name,  variable_name='/data'):
    """writes a matlab compatible hdf5 file. If pre-existing the file is deleted
    
    Inputs:
    - *data* (dict or ndarray): data to save
    - *file_name (string) : path to the file
    - *variable_name* (string): data is save with *variable_name* as a name in the matlab structure
    """
    #delete file if exists
    if os.path.isfile(file_name):
        os.remove(file_name)    
    options=hdf5storage.Options(matlab_compatible=True,  store_python_metadata=True)
    if variable_name[0]!='/':
        variable_name='/'+variable_name
    variable_name=unicode(variable_name)
    if isinstance(data, dict):
        hdf5storage.write(data,  path=variable_name,  filename=file_name,  options=options)
    else:
        dico={variable_name: data}
        hdf5storage.write(dico,  path=variable_name,  filename=file_name,  options=options)

