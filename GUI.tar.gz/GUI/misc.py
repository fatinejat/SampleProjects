import numpy
import pymaxflow
from Tkinter import  *
from math import exp



def compute_size(data):
    """computes a rough estimate of the size on disk of an object
    
    Inputs:
    
    - *data* (dict, or ndarray, or simple types): object of which we want the size
    
    Outputs:
    
    - int : estimated size of *data*
    
    """
    size=0
    if isinstance(data, dict):
        for key,  value in data.items():
            size=size+compute_size(value)
    elif isinstance(data, numpy.ndarray ):
        size=data.size*data.dtype.itemsize
    else:
        #coarse estimation: if one element is 8 bytes, 50 are 400 bytes
        size=400
    return size
    
def time2sec(t=''):
    """converts a DICOM formated time to a number of seconds
    
    Inputs:
    
    - *t* (string): time with 2 digits for hours, 2 for minutes, the rest for seconds
    
    Outputs:
    -int : t converted to seconds
    """
    
    time=int(t[0:2])*3600+int(t[2:4])*60+float( t[4:len(t)] )
    return time

def isfloat(value):
    """test if *value* is convertible to float
    
    Inputs:
    - *value* (any type): value to test
    
    Outputs: 
    
    - boolean
    """
    try:
        float(value)
        return True
    except ValueError:
        return False
        
def contains_bool(data):
    """tests if a dictionnary or an ndarray contains booleans
    
    Inputs:
    
    - *data* : data to test
    
    Outputs:
    
    - boolean
    
    """
    
    res=False
    if isinstance(data, dict):
        for k, v  in data.items():
            res=res|contains_bool(v)
    elif isinstance(data,  numpy.ndarray):
        res=(data.dtype==numpy.bool)
    else:
        res=isinstance(data,  bool)
    return res
    
def weight(w,  data):
    """returns the data weighted by w
    
    Inputs:
    
    - *w* (numpy array): weights
    - *data* (numpy array): data to weight
    
    Outputs: 
    
    -numpy array (size of data): weighted data
    """
    if w.shape!=data.shape:
        raise ValueError('The weights and the data must have the same size')
    d1=100*numpy.sum(w*data, 1)/numpy.sum(w, 1)
    return d1
    
def gaussian_mixture(X,  w1,  m1,  s1,  w2,  m2,  s2):
    """computes a gaussian-like mixture of the data in X with the parameters in A
    
    Inputs:
    
    - *X* (numpy array [nsamplesX1]): data
    - *A* (numpy array [ncomponentsX3]): parameters of the gaussians (every line: weight, mean, std)
    
    Outputs:
    
    - numpy array [nsamplesX1]: gaussian like mixture
    
    """
    
    res=w1*numpy.exp(-numpy.square(X-m1)/(s1**2))+w2*numpy.exp(-numpy.square(X-m2)/(s2**2))
    return res

def bone_reg(im,  mask,  HT,  me,  st,  metadata):
    """ performs the regularization of a bone mask defined by im>HT by graph cut
    
    Inputs:
    
    - *im* (numpy array): image
    - *mask* (numpy array, size of im): body mask of *im*
    - *HT* (float): intensity threshold for first estimation of bones
    - *me*, *st* (float): mean and std of bone intensity distribution
    - *metadata*: metadata of the image
    
    Outputs:
    
    - (numpy array): mask of bones in *im*
    """
    
    if im.shape!=mask.shape:
        raise ValueError('The image and the mask should have the same size')
    print("Number of nodes: "+ str(mask.sum()))
    
    bones=im>HT
    
    if bones.sum()>0:
    
        #regularization by graph cut
        indices=mask.astype(numpy.int32)
        indices[mask==1]=range(0,  mask.sum())
        g = pymaxflow.PyGraph(mask.sum(), mask.sum()* 2)
        g.add_node(mask.sum())
        #terminal edges
        Tweights=numpy.ones(shape=im.shape)
        Tweights[im>(1.2*HT)]=4
        mtemp=im<HT
        Tweights[mtemp]=numpy.exp(-numpy.square(im[mtemp]-me)/(st*st))
        g.add_tweights_vectorized(indices[mask==1], 1-Tweights[mask==1].astype(numpy.float32),Tweights[mask==1].astype(numpy.float32))
        del Tweights
        
        if 'PixelSpacing' in metadata:
            dx=metadata['PixelSpacing'][0]
            dy=metadata['PixelSpacing'][1]
        else:
            dx=1
            dy=1
        if 'SliceThickness' in metadata:
            dz=float(metadata['SliceThickness'])
        else:
            dz=1
       
        if True:
            #z
            mtemp=mask[:, :, 1:]*mask[:, :, :-1]
            u=im[:, :, 1:]
            u1=im[:, :, :-1]
            weights=numpy.exp(-numpy.square(u[mtemp]-u1[mtemp])/(st*st))*exp(-(dz**2))
            u=indices[:, :, 1:]
            u1=indices[:, :, :-1]
            g.add_edge_vectorized(u[mtemp], u1[mtemp],weights, weights)
            #y
            mtemp=mask[:, 1:, :]*mask[:, :-1, :]
            u=im[:, 1:, :]
            u1=im[:, :-1, :]
            weights=numpy.exp(-numpy.square(u[mtemp]-u1[mtemp])/(st*st))*exp(-(dy**2))
            u=indices[:, 1:, :]
            u1=indices[:, :-1, :]
            g.add_edge_vectorized(u[mtemp], u1[mtemp],weights, weights)
            #x
            mtemp=mask[1:, :, :]*mask[:-1, :, :]
            u=im[1:, :, :]
            u1=im[:-1, :, :]
            weights=numpy.exp(-numpy.square(u[mtemp]-u1[mtemp])/(st*st))*exp(-(dx**2))
            u=indices[1:, :, :]
            u1=indices[:-1, :, :]
            g.add_edge_vectorized(u[mtemp], u1[mtemp],weights, weights)
            #zx
            mtemp=mask[1:, :, 1:]*mask[:-1, :, :-1]
            u=im[1:, :, 1:]
            u1=im[:-1, :, :-1]
            weights=numpy.exp(-numpy.square(u[mtemp]-u1[mtemp])/(st*st))*exp(-(dz**2+dx**2))
            u=indices[1:, :, 1:]
            u1=indices[:-1, :, :-1]
            g.add_edge_vectorized(u[mtemp], u1[mtemp],weights, weights)
            #zy
            mtemp=mask[:, 1:, 1:]*mask[:, :-1, :-1]
            u=im[:, 1:, 1:]
            u1=im[:, :-1, :-1]
            weights=numpy.exp(-numpy.square(u[mtemp]-u1[mtemp])/(st*st))*exp(-(dz**2+dy**2))
            u=indices[:, 1:, 1:]
            u1=indices[:, :-1, :-1]
            g.add_edge_vectorized(u[mtemp], u1[mtemp],weights, weights)
            #yx
            mtemp=mask[1:, 1:, :]*mask[:-1, :-1, :]
            u=im[1:, 1:, :]
            u1=im[:-1, :-1, :]
            weights=numpy.exp(-numpy.square(u[mtemp]-u1[mtemp])/(st*st))*exp(-(dy**2+dx**2))
            u=indices[1:, 1:, :]
            u1=indices[:-1, :-1, :]
            g.add_edge_vectorized(u[mtemp], u1[mtemp],weights, weights)
            #zyx
            mtemp=mask[1:, 1:, 1:]*mask[:-1, :-1, :-1]
            u=im[1:, 1:, 1:]
            u1=im[:-1, :-1, :-1]
            weights=numpy.exp(-numpy.square(u[mtemp]-u1[mtemp])/(st*st))*exp(-(dz**2+dy**2+dx**2))
            u=indices[1:, 1:, 1:]
            u1=indices[:-1, :-1, :-1]
            g.add_edge_vectorized(u[mtemp], u1[mtemp],weights, weights)
        g.maxflow()
        bones=mask
        bones[mask] = g.what_segment_vectorized()
    
    return bones
