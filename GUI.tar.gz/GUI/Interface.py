#from tkinter import  *
#from tkinter.ttk import *
from tkFileDialog import askopenfilename
from tkFileDialog import asksaveasfilename
import math
import re
#import matplotlib.pyplot as plt
#import numpy
#import scipy
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from PIL import Image as ImagePIL
from PIL import ImageTk

from  GUI.LinkedScrollBar import *
from  GUI.image import *

import numpy as np
import pickle
import os

class Interface(Frame):
    """ **GUI class that manages the interaction with the user**
    
    Members:
    
    - *_image*: ImageW instance of the current 3d image
    
    - *_imagelabel*: list of objects (one for each dimensions) that displays 2d slices of the current image 
    - *_image_size*: actual displayed size for the images
    - *_zoom*: zoom from the original images (in pixel)
    
    - *_sliceLabel*: text for the slice
    - *_sliceLabelNumber*: coordinate of the displayed slice
    
    - *_goto*: text for choosing the slice
    - *_newSlice*: field to enter the number of the slice wished (bound to *gotoslice()*, and *select()*)
    
    - *_intensity*: text for CT intensity
    - *_intensityScroll*: LinkedScrollBar for maximum displayed CT intensity
    - *_sliceScroll*: list of LinkedScrollBar instances for the coordinates of the displayed slices
    
    - *_minSlices*: list of Entry instances for displaying the lower box coordinates
    - *_maxSlices*: list of Entry instances for displaying the upper box coordinates
    
    - *_openButton*: button for opening new PET/CT files (calls *open_CT()*)
    - *_quitButton*: button to quit
    
    """
    
    def __init__(self, master, image_path='',  im=None):
        """creates frames and add widgets""" 
        
        # Create main frame
        self.master=master
        master.columnconfigure(0, weight=1)
        master.rowconfigure(0, weight=1)
        Frame.__init__(self, master,  padding="3 3 3 3")
        
        # Position and configure a widget in the parent widget in a grid
        self.grid(column=0,  row=0,  sticky=[ 'e',  'w', 's', 'n' ])
        self.columnconfigure(0, weight=2)
        self.rowconfigure(1, weight=5)
        
        # Set a bit of style
        self._imStyle = Style()
        self._imStyle.configure("Red.TFrame", background="green")
        #self.configure(style="Red.TFrame")
        self.bind("<Configure>", self.resize)# resize() at event <Configure>
        
        # Configure the main frame with image cells, side option cells and button cells on the top
        self._image_path = image_path
        self.add_images()
        self.add_side_frame()
        self.add_button_frame()
        
        #initialize the display
        self.reset_val()
        
    def add_images(self):
        """add the image, with resize and zoom bindings"""
        
        # Set image-related class variables 
        if len(self._image_path)==0:
            self._image = ImageW(size=(256, 256, 2))
        else:
            self._image = ImageW(path=self._image_path)
            
        # add image frame in main frame at row 1 column 2 and divide in two columns
        self._imageFrame = Frame(self)
        self._imageFrame.grid(column=0,  row=1,    sticky=[ 'e',  'w', 's', 'n' ])
        self._imageFrame.rowconfigure(1, weight=2)
        self._imageFrame.columnconfigure(1, weight=0)
        
        # set images within the image frame and bind actions
        self._imagelabel=[];self._sliceLabelNumber=[];
        self._newSlice=[];self._sliceScroll=[]
        row_ind = [3,0,0]
        col_ind = [4,4,0]

        for i in range(3):
            self._imagelabel.append(Label(self._imageFrame,anchor = CENTER,))
            self._imagelabel[i].grid(column=col_ind[i],  row=row_ind[i],  
                columnspan = 4, sticky=[ 'e',  'w', 's', 'n' ])
            offset = 1
                
            #self._imagelabel[i].bind("<Configure>", self.resize)
            self._imagelabel[i].bind("<Button 4>", lambda event, arg=i: self.slice_up(arg))
            self._imagelabel[i].bind("<Button 5>", lambda event, arg=i: self.slice_down(arg))
            self._imagelabel[i].bind("<Button-1>", lambda event, arg=i: self.select(event,arg))
            self._imagelabel[i].bind("<Button-3>", lambda event, arg=i: self.update_intensities(event,arg))
            self._imagelabel[i].bind("<B3-Motion>", lambda event, arg=i: self.update_intensities(event,arg))
            
            # Make field to display current slice 
            _sliceLabel=Label(self._imageFrame,  text='Slice displayed : ')
            _sliceLabel.grid(column=col_ind[i],  row=row_ind[i]+offset, sticky=[ 'w','e'])
            
            self._sliceLabelNumber.append(Label(self._imageFrame))
            self._sliceLabelNumber[i].grid(column=col_ind[i]+1,  row=row_ind[i]+offset,  
                sticky=[ 'w','e' ])
            
            # Make a 'go to '-field
            
            _goto=Label(self._imageFrame, text=' - go to slice :')
            _goto.grid(column=col_ind[i]+2, row=row_ind[i]+offset, sticky=[ 'w','e'])
            
            self._newSlice.append(Entry(self._imageFrame,width=6))
            self._newSlice[i].bind('<Return>',  lambda event,arg=i: self.gotoslice(arg))
            self._newSlice[i].bind('<KP_Enter>',  lambda event,arg=i: self.gotoslice(arg))
            self._newSlice[i].grid(column=col_ind[i]+3, row=row_ind[i]+offset, sticky=[ 'w','e' ]) 
        
            # Add a scrollbar for navigating through the slices
            
            self._sliceScroll.append( LinkedScrollBar(master=self._imageFrame, 
                minVal=0,  maxVal=self._image.size()[i]-1, step=1,  
                command=lambda: self.disp_im(),  orient='horizontal') )
            self._sliceScroll[i].grid(column=col_ind[i], row=row_ind[i]+offset+1, 
                columnspan=4,  sticky=[ 'e',  'w', 's' ])
        
    def add_side_frame(self):    
        '''add a side frame for scrollbars and navigation'''
        
        # Add a side frame in the main frame and put 9 rows in it
        _sideFrame=Frame(self._imageFrame)
        _sideFrame.grid(column=0,  row=3, columnspan=4, sticky=[ 'e',  'w',  'n', 's' ])
        # if cell is larger on which sides will this widget stick to the cell boundary      
        
        empty2=Label(_sideFrame)
        empty2.grid(column=0,  row=0)
        empty2=Label(_sideFrame)
        empty2.grid(column=0,  row=1)
        
        # Make a scrollbar-field to change intensity
        _intensity=Label(_sideFrame, text='Max intensity :')
        _intensity.grid(column=0,  row=2,  sticky=[ 'w' ])
        self._intensityScroll=LinkedScrollBar(master=_sideFrame, initVal='max',  step=50,  
                command=lambda: self.disp_im(),  orient='horizontal',  
                minVal=self._image.min,  maxVal=self._image.max)
        self._intensityScroll.grid(column=1,  row=2, columnspan=3, sticky=[ 'e',  'w' ])
        
        empty2=Label(_sideFrame)
        empty2.grid(column=0,  row=3)
        
        # Make a field to read intensities
        _intensityText=Label(_sideFrame,  text='Intensity: ')
        _intensityText.grid(column=0,  row=4, sticky=[  'w' ])
        self._intensity=Label(_sideFrame)
        self._intensity.grid(column=1,  row=4, sticky=[  'w' ])
        
        empty2=Label(_sideFrame)
        empty2.grid(column=0,  row=5)
            
        # Make a field to visualise selected slices
        directions = ['x','y','z'];self._minSlices=[];self._maxSlices=[]
        for i in range(3):
            # Make field to display current slice
            _sliceLabel=Label(_sideFrame,  text=directions[i]+'-slices: ')
            _sliceLabel.grid(column=0,  row=i+6,   sticky=[ 'w' ])
            self._minSlices.append(Entry(_sideFrame, width=6))
            self._minSlices[i].bind('<Return>',  lambda event, arg = [0,i]: self.save_slice(arg[0],arg[1]))
            self._minSlices[i].bind('<KP_Enter>',  lambda event, arg = [0,i]: self.save_slice(arg[0],arg[1]))
            self._minSlices[i].grid(column=1,  row=i+6,   sticky=[ 'w' ])
            _sliceLabel2=Label(_sideFrame,  text=' up to ')
            _sliceLabel2.grid(column=2,  row=i+6,   sticky=[ 'w' ])
            self._maxSlices.append(Entry(_sideFrame, width=6))
            self._maxSlices[i].bind('<Return>',  lambda event, arg = [1,i]: self.save_slice(arg[0],arg[1]))
            self._maxSlices[i].bind('<KP_Enter>',  lambda event, arg = [1,i]: self.save_slice(arg[0],arg[1]))
            self._maxSlices[i].grid(column=3,  row=i+6,   sticky=[ 'w' ])
        
        
        
    def add_button_frame(self):
        '''add a button frame'''
        self._buttonFrame=Frame(self)
        self._buttonFrame.grid(column=0,  row=0,  sticky=[ 'e',  'w' ])
        for i in range(0,  4):
            self._buttonFrame.grid_columnconfigure(i, weight=1, uniform="button")
        
        #first column
        #add a quit button
        self._quitButtonStyle = Style()
        self._quitButtonStyle.configure("Red.TButton", foreground="red")
        self._quitButton = Button(
            self._buttonFrame,  text="FINISH", 
            command=lambda: self.disp_yes_no_popup(
                msg="Current boundary slices:\n x from "+str(self._minCo[0])+" to "+str(self._maxCo[0])+\
                "\n y from "+str(self._minCo[1])+" to "+str(self._maxCo[1])+\
                "\n z from "+str(self._minCo[2])+" to "+str(self._maxCo[2])+\
                "\nDo you agree on these coordinates?",  
                command_yes=self._quit
                )
            )
        self._quitButton.configure(style="Red.TButton")
        self._quitButton.grid(column=0,  row=0,  sticky=[ 'e',  'w' ])
        
        self._helpButton=Button(self._buttonFrame,  text="HELP",command=self.display_help)
        self._helpButton.grid(column=0,  row=1,  sticky=[ 'e',  'w' ])
        
        #add an open file button
        self._openButton = Button(self._buttonFrame,  text="Open image file", command=self.open_image)
        self._openButton.grid(column=1,  row=0,  sticky=[ 'e',  'w' ])
        #display bounding box butten
        self._boxButton = Button(self._buttonFrame,  text="Display bounding box", 
                                        command=self.activate_box_visualisation)
        self._boxButton.grid(column=1,  row=1,  sticky=[ 'e',  'w' ])
        
        #add a save button
        self._saveButton = Button(self._buttonFrame,  text="Save coordinates", command=self.save_auto)
        self._saveButton.grid(column=2,  row=0,  sticky=[ 'e',  'w' ])
        #add a save button
        self._saveAsButton = Button(self._buttonFrame,  text="Save coordinates as ...", command=self.save)
        self._saveAsButton.grid(column=2,  row=1,  sticky=[ 'e',  'w' ])
        
        #add a swap dimension Button
        self._swapButton=Button(self._buttonFrame,  text="Zoom in", command=self.zoom_in)
        self._swapButton.grid(column=3,  row=0,  sticky=[ 'e',  'w' ])
        #add a reverse z direction Button
        self._switchzButton=Button(self._buttonFrame,  text="Zoom out", command=self.zoom_out)
        self._switchzButton.grid(column=3,  row=1,  sticky=[ 'e',  'w' ])
        
    def setPriorBoundaries(self):
        
        if self._image_path in self.path_dictionary:
            self._minCo = self.path_dictionary[self._image_path][0]
            self._maxCo = self.path_dictionary[self._image_path][1]
            for axis in range(3):
                self._minSlices[axis].delete(0,END)
                self._minSlices[axis].insert(0,self._minCo[axis])
                self._maxSlices[axis].delete(0,END)
                self._maxSlices[axis].insert(0,self._maxCo[axis])
        else:
            self._minCo = [None,None,None]
            self._maxCo = [None,None,None]
        
    def reset_val(self):
        """reset all visualisation values to default"""
        
        self._image_size = [(self._image.size()[1],  self._image.size()[2]),
                            (self._image.size()[0],  self._image.size()[2]),
                            (self._image.size()[0],  self._image.size()[1])]
        self._image_view = [None]*3 
        self._boundingBoxIm = None
        self._showBox = False
        self._zoom=0
        self._intensityScroll.reset( minVal=self._image.min,  maxVal=self._image.max)
        self._intensity['text']=''
        for axis in range(3):
            self._sliceScroll[axis].reset(maxVal=self._image.size()[axis]-1)
        self.disp_im()
        
        # Load image path dictionary and initialise boundaries
        with open(os.path.join(os.path.dirname(os.path.realpath(__file__)),
                'boundary_history_dictionary.pickle')) as f:
            self.path_dictionary = pickle.load(f)
        self.setPriorBoundaries()
        
        self._popup = None
        self._popup_ok = None
        
        self._save_path = None
 
    def open_image(self):
        """used for opening an image
        all visualization values are reset to default and the images are replaced"""
        path=askopenfilename(title='Choose an image file')
        self._image = ImageW(path)
        self._image_path = path
        self.setPriorBoundaries()
    
    def slice_up(self,  axis):
        """increase slice number"""
        self._sliceScroll[axis].set_value(self._sliceScroll[axis].val+1)
        self.disp_im()
        
    def slice_down(self,  axis):
        """decrease slice number"""
        self._sliceScroll[axis].set_value(self._sliceScroll[axis].val-1)
        self.disp_im(axis)
        
    def zoom_in(self,  *args):
        """modifies the zoom value and actualise the display"""
        self._zoom=self._zoom+10
        self._zoom=min(self._zoom,  math.floor(self._image.size()[0]/2)-10, 
            math.floor(self._image.size()[1]/2)-10,  math.floor(self._image.size()[2]/2)-10)
        self.disp_im()
        
    def zoom_out(self,  *args):
        """modifies the zoom value and actualise the display"""
        self._zoom=self._zoom-10
        self._zoom=max(self._zoom,  0)
        self.disp_im()
        
    def gotoslice(self,axis=None,slice_index=None):
        """moves to the desired slice"""
        
        if slice_index is None:
            z=self._newSlice[axis].get()
        else:
            z = slice_index
        #if not an integer
        try:
            z=int(z)
            #if out of range
            if (z<0):
                self.disp_popup(msg='Slice number is negative - please enter a valid slice number')
                self._newSlice[axis].delete(0,  END)
            elif (z>self._image.size()[axis]):
                self.disp_popup(msg='Slice number is too high - please enter a valid slice number')
                self._newSlice[axis].delete(0,  END)
            else:
                self._sliceScroll[axis].set_value(z)
                self._newSlice[axis].delete(0,  END)
        except ValueError as e:
            print e
            self.disp_popup(msg='Please enter a valid slice number')
            self._newSlice[axis].delete(0,  END)
            
    def select(self, event, axis):
        """the function is called when an image is left-clicked. """
        
        self.update_idletasks()
        
        # Get slice number
        z = int(self._sliceScroll[axis].val)
        if self._minSlices[axis].get() == '':
            self._minSlices[axis].delete(0,END)
            self._minSlices[axis].insert(0,z)
            self.save_slice(0, axis, z)
        else:
            if z > int(self._minSlices[axis].get()):
                self._maxSlices[axis].delete(0,END)
                self._maxSlices[axis].insert(0,z)
                self.save_slice(1, axis, z)
            else:
                z_max = int(self._minSlices[axis].get())
                self._maxSlices[axis].delete(0,END)
                self._maxSlices[axis].insert(0,z_max)
                self.save_slice(1, axis, z_max)
                self._minSlices[axis].delete(0,END)
                self._minSlices[axis].insert(0,z)
                self.save_slice(0, axis, z)
        # Store slice number
        
    def save_slice(self,upper,axis,slice_index=None):
        
        if slice_index is None:
            if not upper:
                new_co = self._minSlices[axis].get()
            else:
                new_co = self._maxSlices[axis].get()
                
            if new_co == '':
                if not upper:
                    self._minCo[axis] = None
                else:
                    self._maxCo[axis] = None
                return
            else:
                try:
                    new_co = int(new_co)
                except ValueError as e:
                    print e
                    self.disp_popup(msg="Boundaries should be indicated by slice indices (integers)")
                    if not upper:
                        self._minSlices[axis].delete(0,  END)
                    else:
                        self._maxSlices[axis].delete(0,  END)
        else:
            new_co = slice_index
            

        if new_co > 0 and new_co < self._image.size()[axis]:
            if not upper:
                self._minCo[axis] = new_co
            else:
                self._maxCo[axis] = new_co
        else:
            self.disp_popup(msg="Boundary slice is not within valid range")
            if not upper:
                self._minSlices[axis].delete(0,  END)
            else:
                self._maxSlices[axis].delete(0,  END)
        
    def update_intensities(self, event, axis):
        y=(self._zoom+round(self._image.size_2d(axis)[1]-2*self._zoom))/np.float(self._image_size[axis][1])*\
                (event.x-((self._imagelabel[axis].winfo_width()-self._image_size[axis][1])/2))
        x=(self._zoom+round(self._image.size_2d(axis)[0]-2*self._zoom))/np.float(self._image_size[axis][0])*\
                (event.y-((self._imagelabel[axis].winfo_height()-self._image_size[axis][0])/2))
        
        co = [0,0,0]
        x_axes = [1,0,0];x_axis=x_axes[axis];co[x_axis] = x
        y_axes = [2,2,1];y_axis=y_axes[axis];co[y_axis] = y
        z_axes = [0,1,2];z_axis=z_axes[axis];co[z_axis] = int(self._sliceScroll[axis].val)

        i=self._image.img[tuple(co)]
        self._intensity['text']=str(round(i*100)/100)

        self.gotoslice(axis=x_axis, slice_index=x)
        self.gotoslice(axis=y_axis, slice_index=y)
        self.disp_im()
        
    def swap_xy(self):
        """switches the x and y dimensions of all the images"""
        self._image.img=numpy.transpose(self._image.img,  [1,  0,  2])
        
        if self._boundingBoxIm is not None:
            self._boundingBoxIm.img=numpy.transpose(self._boundingBoxIm.img,  [1,  0,  2])
        self.disp_im()
        
    def switch_z_direction(self):
        """reverse the z order of all the images"""
        self._image.img=self._image.img[:, :, ::-1]
        if self._boundingBoxIm is not None:
            self._boundingBoxIm.img=self._boundingBoxIm.img[:, :, ::-1]
        self.disp_im()
        
    def activate_box_visualisation(self):
        """ Function called if 'show bounding box' button is activated """
        if None in self._minCo or None in self._maxCo:
            self.disp_popup(msg="Bounding box coordinates are not yet complete")
        else:
            self._showBox = True
            self.disp_im()
            
    def add_bounding_box(self, image, axis):
        """superimpose in red the bounding box"""
        if (not None in self._minCo) and \
                      (not None in self._maxCo):
            r,  g,  b=image.convert('RGB').split()
            
            tlc = self._minCo;tuc = self._maxCo
            np_box = np.zeros(self._image.size(),  dtype='uint8')
            np_box[tlc[0]:tuc[0]+1,tlc[1]:tuc[1]+1,tlc[2]:tuc[2]+1] = 1
            np_box[tlc[0]+1:tuc[0],tlc[1]+1:tuc[1],tlc[2]+1:tuc[2]] = 0
            
            box_slice=self.convert_im(ImageW(img=np_box), 1, axis)
            r=ImagePIL.fromarray(numpy.maximum(numpy.array(r), 
                numpy.array(box_slice), dtype='uint8'),  mode='L')
                
            return ImagePIL.merge("RGB", (r, g, b))
        else:
            return image
        
    def add_slice_lines(self, image, axis):
        """superimpose in blue the slice lines"""

        r,  g,  b=image.convert('RGB').split()
        
        np_box = np.zeros(self._image.size(),  dtype='uint8')

        if axis!=0:
            np_box[self._sliceScroll[0].val,:,:] = 1
        if axis!=1:
            np_box[:,self._sliceScroll[1].val,:] = 1
        if axis!=2:
            np_box[:,:,self._sliceScroll[2].val] = 1
        
        box_slice=self.convert_im(ImageW(img=np_box), 1, axis)
        b=ImagePIL.fromarray(numpy.maximum(numpy.array(b), 
            numpy.array(box_slice), dtype='uint8'),  mode='L')
            
        return ImagePIL.merge("RGB", (r, g, b))
        
    def disp_im(self, axis = None):
        """use the size, slice and zoom to display the image"""
         
        if axis is None:
            axices = range(3)  
        else:
            axices = [axis]  
                
        for i in axices:
            temp_im=self.convert_im(self._image, self._intensityScroll.val-self._image.min,i)
            
            temp_im=self.add_slice_lines(temp_im, i)
            
            # create the 2d view with or without the bounding box
            if self._showBox:
                if None in self._minCo or None in self._maxCo:
                    self.disp_popup(msg="Bounding box coordinates are not complete")
                    self._showBox = False
                else:
                    self._image_view[i] = ImageTk.PhotoImage( self.add_bounding_box(
                        temp_im, i) )
            else:
                self._image_view[i] = ImageTk.PhotoImage(temp_im)
            
            # set the view in the frame
            self._imagelabel[i]['image']=self._image_view[i]
            
            # update slice label
            self._sliceLabelNumber[i]['text']=str(int(self._sliceScroll[i].val))
            
    def convert_im(self, image,  maxInt,  axis):
        """get the image to display from a 3D Image"""
        
        pix = numpy.array(image.get_slice(axis, int(self._sliceScroll[axis].val)), dtype='float')
        pix=pix-pix.min()
        maxInt=maxInt-pix.min()
        if maxInt==0:
            maxInt=0.00001
        pix=pix[self._zoom:(pix.shape[0]-self._zoom),  self._zoom:(pix.shape[1]-self._zoom)]
        if pix.shape !=self._image_size[axis]: 
            return ImagePIL.fromarray(pix*255/maxInt).resize(self._image_size[axis][::-1], ImagePIL.ANTIALIAS)
        else:
            return ImagePIL.fromarray(pix*255/maxInt)
            
        
#     def disp_distrib(self,  im_name='',  mask_name='',  title=''):
#         """displays in a popup the intensity distribution of the mask
#         
#         Inputs:
#         
#         - *im_name* (string): name of the image used for the intensity
#         - *mask_name* (string): name of the mask for which the distribution is computed
#         - *title* (string): Title of the popup
#         """
#         if getattr(self, mask_name) is None:
#             self.disp_popup(msg='The mask '+ mask_name +' is not defined. Please open it')
#         elif getattr(self, im_name) is None:
#             self.disp_popup(msg='The image '+ im_name +' is not defined. Please open it')
#         else:
#             distrib=getattr(self, im_name).img[getattr(self, mask_name).img>0]
#             f = Figure()
#             p=f.gca()
#             p.hist(distrib,  bins=50,  normed=True)
#             
#             histPopup=Toplevel(self)
#             histPopup.title(title)
#             canvas=FigureCanvasTkAgg(f,  master=histPopup)
#             canvas.show()
#             canvas.get_tk_widget().grid(row=0,  column=0)
#             quitButton=Button(histPopup,  text='Quit',  command=histPopup.destroy)    
#             quitButton.grid(row=1,  column=0)
            
#     def compute_lesions_from_threshold(self,  step=1):
#         """checks if we want to save the current lesion image if exists and requires a threshold for computing the lesions by thresholding the PET image"""
#         if step==1:
#             if self._bones is None:
#                 self.disp_popup(msg='Please first open a bone file')
#             else:
#                 if not (self._lesionImage is None):
#                     self.disp_yes_no_popup(msg="Do you want to save the current lesions image", command_yes=self.save_lesions)
#                 self._popup_entry=Toplevel(self);
#                 self._popup_entry.geometry('+'+str(int(self.master.winfo_x()+self.master.winfo_width()/2))+'+'+str(int(self.master.winfo_y()+self.master.winfo_height()/2)))
#                 matMsg=Label(self._popup_entry,  text='Please enter a threshold to compute the lesions')
#                 matMsg.grid(column=0,  row=0)
#                 self._thEntry=Entry(self._popup_entry)
#                 self._thEntry.grid(column=0,  row=1)
#                 self._thEntry.bind('<Return>',  lambda event: self.compute_lesions_from_threshold(step=2))
#                 self._thEntry.bind('<KP_Enter>',  lambda event: self.compute_lesions_from_threshold(step=2))
#                 self.wait_window(self._popup_entry)
#         else:
#                 th=self._thEntry.get()
#                 self._popup_entry.destroy()
#                 try:
#                     th=float(th)
#                     self._lesionImage=ImageW(img=((self._PETimage.img>th)&self._bones.img))
#                     self.open_lesion()
#                 except ValueError:
#                     self.disp_popup(msg='Please enter a valid threshold')
        
#     def open_lesion(self):
#         """actions to do when opening a lesion file"""
#         label_im, nb_labels=ndimage.label(self._lesionImage.img>0)
#         self._nb_positives=nb_labels
#         self._nb_false_positives=0
#         self._lesionImage =ImageW(img=label_im)
#         self.disp_im()
        
    def resize(self,  event):  
        """handles the resizing of the image in case the window is resized"""
        self.update_idletasks()
        for i in range(3):
            width_factor = (self._imagelabel[i].winfo_width() - 2) / np.float(self._image_size[i][1])
            height_factor = (self._imagelabel[i].winfo_height() - 2) / np.float(self._image_size[i][0])
            if width_factor > height_factor:
                height = np.round(self._image_size[i][0] * height_factor)
                width = np.round(self._image_size[i][1] * height_factor)
            else:
                height = np.round(self._image_size[i][0] * width_factor)
                width = np.round(self._image_size[i][1] * width_factor)

            self._image_size[i]=(max(int(height), 1),max(int(width), 1))
            
        self.disp_im()            
    
    def open_file(self, var_name, path='',  action=None,  msg='Choose a file'):
        """Used for opening a file."""
        if len(file)==0:
            path=askopenfilename(title=msg)
        if len(path)>0:
            if (path[(len(path)-4):(len(path))]=='.nii'):
                setattr(self, var_name,  ImageW(path))
                if not (action is None):
                    action()
                return 1
            else:
                self.disp_popup(msg="Please choose a file with .mat extension")
                return 0
        else:
            return 0

#     def check_lesion_image(self):
#         """checks if a lesion image is present. If not, forbids the false positive category"""
#         if self._lesionImage is None:
#             self._selection.set(0)
#             self.disp_popup(msg='Please open or compute a lesion image first.')
        
    def disp_yes_no_popup(self,  msg='',  command_yes=None,  command_no=None):
        """displays a popup with *msg* as text and three button.
        Since the application will wait on the popup, the commands of the button MUST destroy it"""
        self.update_idletasks()
        self._popup=Toplevel(self);
        self._popup.geometry('+'+str(int(self.master.winfo_x()+self.master.winfo_width()/2))+'+'+str(int(self.master.winfo_y()+self.master.winfo_height()/2)))
        saveMsg=Label(self._popup,  text=msg)
        saveMsg.grid(column=0,  row=0,  columnspan=3)
        if command_no is None:
            command_no=self._popup.destroy
        if command_yes is None:
            command_yes=self._popup.destroy
        noButton=Button(self._popup,  text="No", command=command_no)
        noButton.grid(column=0,  row=2,  sticky=[ 'e',  'w', 's',  'n' ])
        yesButton=Button(self._popup,  text="Yes", command=command_yes)
        yesButton.grid(column=1,  row=2,  sticky=[ 'e',  'w', 's',  'n' ])
        cancelButton=Button(self._popup,  text="Cancel", command=self._popup.destroy)
        cancelButton.grid(column=2,  row=2,  sticky=[ 'e',  'w', 's',  'n' ])
        self.wait_window(self._popup)
        
    def disp_popup(self,  msg=''):
        """displays a popup with *msg* as text and a button to close it"""
        self._popup_ok=Toplevel(self)
        self._popup_ok.geometry('+'+str(int(self.master.winfo_x()+self.master.winfo_width()/2))+'+'+str(int(self.master.winfo_y()+self.master.winfo_height()/2)))
        matMsg=Label(self._popup_ok,  text=msg)
        matMsg.grid(column=0,  row=0)
        okButton=Button(self._popup_ok,  text="Ok", command=self._popup_ok.destroy)
        okButton.grid(column=0,  row=1)
        self.wait_window(self._popup_ok)
                
    def save(self, path = None):
        """saves lesions and lymph nodes if exist then quit"""
        
        if self._popup is not None:
            self._popup.destroy()
        re = self.save_coordinates(path = path)
        if re>0:
            self.quit()
            
    def save_auto(self):
        """saves lesions and lymph nodes if exist then quit"""
        
        if self._popup is not None:
            self._popup.destroy()
        if self._save_path is None:
            self.disp_popup(" No auto path given to save the coordinates. "+\
                            "\n Press 'save coordinates as ...' if you want to store the coordinates to a path. "+\
                            "\n Press 'FINISH' if you want to return the coordinates to your application. ")
        else:
            re = self.save_coordinates(path=self._save_path)
            if re>0:
                self.quit()
        
    def save_coordinates(self, path=None):
        """save the lesion image as true and false positive separate files if available"""
        
        if self._popup is not None:
            self._popup.destroy()
        if None in self._minCo or None in self._maxCo:
            self.disp_popup(msg='Boundary box coordinates not complete')
            return 0
        else: 
            if path is None:
                path=asksaveasfilename(title='Choose a file to save the boundary coordinates',  
                    filetypes=(('Mat files','*.mat'), ("All Files", "*.*")),  defaultextension='.mat')
            
            if len(path)>0:
                boundary_co = []
                boundary_co[0] = np.asarray(self._minCo)
                boundary_co[1] = np.asarray(self._maxCo)
                io_operations.write_pickle(boundary_co, path)
                
                return 1
            else:
                return 0
    
    def display_help(self):
        helpPopup=Toplevel(self)
        helpPopup.geometry('+'+str(int(self.master.winfo_x()+self.master.winfo_width()/2))+'+'+str(int(self.master.winfo_y()+self.master.winfo_height()/2)))
        helpPopup.rowconfigure(0, weight=2)
        helpPopup.columnconfigure(0, weight=2)
        msg='''Help for the bounding box GUI:\n
        \n
        -LEFT CLICK ON A VIEW: other slices are updated depending on the click position and the intensity in the corresponding voxel is reported
        -RIGHT CLICK ON A VIEW: current slice is selected as a boundary slice. 
        -MOUSE WHEEL: scroll across slices (slow)
        -TEXT FIELDS: go to a given slice (slice indexing starts from 0) or set boundary slice indices (you can empty the fields if you want to reset)
        -SCROLL BARS: to scroll across slices (fast) and to set a maximum grey scale value
        '''
        helpText=Text(helpPopup,  wrap=WORD)
        helpText.insert(END, msg)
        helpText.tag_add('Title',  '1.0', '1.end' )
        helpText.tag_config('Title',  font=('Times', '16',  'bold' ))
        helpText.grid(column=0,  row=0,  stick=['n', 's',  'w',  'e'])
        okButton=Button(helpPopup,  text="Ok", command=helpPopup.destroy)
        okButton.grid(column=0,  row=1)

    def _quit(self):
        if not None in self._minCo and not None in self._maxCo:
            self.path_dictionary[self._image_path] = [self._minCo, self._maxCo]
            with open(os.path.join(os.path.dirname(os.path.realpath(__file__)),
                            'boundary_history_dictionary.pickle'), 'w') as f:
                pickle.dump(self.path_dictionary, f) 
        if self._popup is not None:
            self._popup.destroy()
        if self._popup_ok is not None:
            self._popup_ok.destroy()
        self.quit()
