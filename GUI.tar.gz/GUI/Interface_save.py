#from tkinter import  *
#from tkinter.ttk import *
from tkinter.filedialog import askopenfilename
from tkinter.filedialog import asksaveasfilename
import math
import re
#import numpy
from PIL import Image as ImagePIL
from PIL import ImageTk

from  GUI.LinkedScrollBar import *
from  GUI.image import *


class Interface(Frame):
    """ **GUI class that manages the interaction with the user**
    
    Members:
    
    - *_CTimage*
    - *_PETimage*
    - *_lesionimage*
    - *_lymph*
    - *_bones*
    
    - *_curr_CTim*: current view of the CT image
    - *_curr_PETim*: current view of the PET image
    - *_CTimagelabel*: object that displays *_curr_CTim*
    - *_PETimagelabel*: object that displays *_curr_PETim*
    - *_image_size*: actual displayed size for the images
    - *_zoom*: zoom from the original images (in pixel)
    
    - *_sliceLabel*: text for the slice
    - *_sliceLabelNumber*: coordinate of the displayed slice
    
    - *_goto*: text for choosing the slice
    - *_newSlice*: field to enter the number of the slice wished (bound to *gotoslice()*, and *select()*)
    - *_warninglabel*: label to display a warning
    
    - *_CTintensity*: text for CT intensity
    - *_CTintensityScroll*: LinkedScrollBar for maximum displayed CT intensity
    - *_PETintensity*: text for PET intensity
    - *_PETintensityScroll*:  LinkedScrollBar for maximum displayed PET intensity
    - *_sliceScroll*: LinkedScrollBar for the coordinate of the displayed slice
    
    - *_lesionButton*: button for opening a lesion file (calls *open_lesion()*)
    - *_maskButton*: button for masking the image (calls *mask()*)
    - *_openButton*: button for opening new PET/CT files (calls *open_CT()*)
    - *_quitButton*: button to quit
    
    - *_radioFrame*: Frame for the category selection
    - *_selectionLabel*: selection text
    - *_selection*: variable containing the current category
    - *_R1*: radio button for category 1 (bound to *check_lesion_image()*)
    - *_R2*: radio button for category 2 (bound to *check_lesion_image()*)
    - *_R3*: radio button for category 3
    """
    
    def __init__(self, master, CTFile='',  PETFile='',  lesionFile='',  bonesFile=''):
        """creates frames and add widgets""" 
        
        #set sizes and resizing config
        self.master=master
        master.columnconfigure(0, weight=1)
        master.rowconfigure(0, weight=1)
        Frame.__init__(self, master,  padding="3 3 3 3")
        self.grid(column=0,  row=0,  sticky=[ 'e',  'w', 's', 'n' ])
        self.columnconfigure(0, weight=2)
        self.rowconfigure(1, weight=5)
        self._imStyle = Style()
        self._imStyle.configure("Red.TFrame", background="green")
        self.configure(style="Red.TFrame")
        self.bind("<Configure>", self.resize)
        
        self.add_images(CTFile=CTFile, PETFile=PETFile )
        self.add_side_frame()
        self.add_button_frame()
        
        #initialize the display
        self.reset_val()
        if len(lesionFile)>0:
            self.open_mat_file(file=lesionFile, var_name='_lesionImage',  action=self.open_lesion)
        if len(bonesFile)>0:
            self.open_mat_file(file=bonesFile,  var_name='_bones')
        
    def add_images(self,  CTFile='',  PETFile=''):
        """add the image, with resize and zoom bindings"""
        if len(CTFile)==0:
            self._CTimage=ImageW(size=(256, 256, 2))
            self._PETimage=ImageW(size=(256, 256, 2))
        elif len(PETFile)==0:
                raise ImportError("Please choose a PET file as well")
        else:
            self._PETimage = ImageW(file=PETFile)
            self._CTimage = ImageW(file=CTFile)
        """add an image frame"""
        self._imageFrame=Frame(self)
        self._imageFrame.grid(column=0,  row=1,    sticky=[ 'e',  'w', 's', 'n' ])
        self._imageFrame.rowconfigure(0, weight=2)
        self._imageFrame.columnconfigure(0, weight=2)
        self._imageFrame.columnconfigure(1, weight=2)
        
        
        
        self._CTimagelabel = Label(self._imageFrame,  anchor = CENTER,)
        self._CTimagelabel.grid(column=0,  row=0,  sticky=[ 'e',  'w', 's', 'n' ])
        #self._CTimagelabel.bind("<Configure>", self.resize)
        self._CTimagelabel.bind("<Button 4>", self.zoom_in)
        self._CTimagelabel.bind("<Button 5>", self.zoom_out)
        self._CTimagelabel.bind("<Button-1>",  self.select)
        self._PETimagelabel = Label(self._imageFrame, anchor = CENTER,   background='red')
        self._PETimagelabel.grid(column=1,  row=0,  sticky=[ 'e',  'w', 's', 'n' ])
        #self._PETimagelabel.bind("<Configure>", self.resize)
        self._PETimagelabel.bind("<Button 4>", self.zoom_in)
        self._PETimagelabel.bind("<Button 5>", self.zoom_out)
        #add a scrollbar for navigating trhough the slices
        self._sliceScroll = LinkedScrollBar(master=self._imageFrame, minVal=0,  maxVal=self._CTimage.size()[2]-1, step=1,  command=lambda: self.disp_im(which='both'),  orient='horizontal')
        self._sliceScroll.grid(column=0,  row=1,  columnspan=2,  sticky=[ 'e',  'w' ])
        
    def add_side_frame(self):    
        '''add a side frame for scrollbars and navigation'''
        self._sideFrame=Frame(self)
        self._sideFrame.grid(column=1,  row=1,   sticky=[ 'e',  'w',  'n', 's' ])
        self.rowconfigure(9, weight=2)
        
        #add the actual slice
        self._sliceLabel=Label(self._sideFrame,  text='Slice displayed: ')
        self._sliceLabel.grid(column=0,  row=0,   sticky=[ 'w' ])
        self._sliceLabelNumber=Label(self._sideFrame)
        self._sliceLabelNumber.grid(column=1,  row=0)
        
        #add a 'go to '
        self._goto=Label(self._sideFrame, text='Go to slice :')
        self._goto.grid(column=0,  row=1,   sticky=[ 'w' ])
        self._newSlice=Entry(self._sideFrame)
        self._newSlice.bind('<Return>',  lambda event: self.gotoslice())
        self._newSlice.bind('<KP_Enter>',  lambda event: self.gotoslice())
        self._newSlice.grid(column=1,  row=1,   sticky=[ 'w' ])        
        self._warninglabel=Label(self._sideFrame,  text='',  foreground='red')
        self._warninglabel.grid(column=0,  row=2,  columnspan=2)
        
        #add a scrollbar to change CT intensity
        self._CTintensity=Label(self._sideFrame, text='Max CT intensity :')
        self._CTintensity.grid(column=0,  row=3,   sticky=[ 'w' ])
        self._CTintensityScroll=LinkedScrollBar(master=self._sideFrame, initVal='max',  step=50,  command=lambda: self.disp_im(which='CT'),  orient='horizontal')
        self._CTintensityScroll.grid(column=1,  row=3,  sticky=[ 'e',  'w' ])
        
        #add a scrollbar to change PET intensity
        self._PETintensity=Label(self._sideFrame, text='Max PET intensity :')
        self._PETintensity.grid(column=0,  row=4,   sticky=[ 'w' ])
        self._PETintensityScroll=LinkedScrollBar(master=self._sideFrame, initVal='mid',  step=50,  command=lambda: self.disp_im(which='PET'),  orient='horizontal')
        self._PETintensityScroll.grid(column=1,  row=4,  sticky=[ 'e',  'w' ])
        
        '''add radio buttons for option selection'''
        self._emptyLabel=Label(self._sideFrame)
        self._emptyLabel.grid(column=0,  row=9)
        self._radioFrame=Frame(self._sideFrame)
        self._radioFrame.grid(column=0,  row=10,   columnspan=2,   sticky=[ 'e',  'w', 's',  'n' ])
        self._selectionLabel=Label(self._radioFrame, text='Selection by clicking')
        self._selectionLabel.grid(column=0,  row=0,  sticky=[ 'e',  'w' ])
        self._selection = IntVar()
        self._selection.set(0)
        self._R1 = Radiobutton(self._radioFrame, text="False positive", variable=self._selection, value=1,  command=self.check_lesion_image)
        self._R1.grid(column=0,  row=1)
        self._R1 = Radiobutton(self._radioFrame, text="True positive", variable=self._selection, value=2,  command=self.check_lesion_image)
        self._R1.grid(column=0,  row=2)
        self._R2 = Radiobutton(self._radioFrame, text="Lymph Node", variable=self._selection, value=3)
        self._R2.grid(column=0,  row=3)
        
    def add_button_frame(self):
        '''add a button frame'''
        self._buttonFrame=Frame(self)
        self._buttonFrame.grid(column=0,  row=0,  sticky=[ 'e',  'w' ])
        for i in range(0,  4):
            self._buttonFrame.grid_columnconfigure(i, weight=1, uniform="button")
        
        #first column
        #add a quit button
        self._quitButtonStyle = Style()
        self._quitButtonStyle.configure("Red.TButton", foreground="red")
        self._quitButton = Button(
            self._buttonFrame,  text="QUIT", 
            command=lambda: self.disp_yes_no_popup(
                msg="Do you want to save the lesions/ lymph nodes before quitting?",  
                command_yes=self.save_files,  command_no=self._quit
                )
            )
        self._quitButton.configure(style="Red.TButton")
        self._quitButton.grid(column=0,  row=0,  sticky=[ 'e',  'w' ])
        
        #add an open file button
        self._openButton = Button(self._buttonFrame,  text="Open PET/CT File", command=self.open_CT)
        self._openButton.grid(column=0,  row=1,  sticky=[ 'e',  'w' ])
        
        #2d column
        #add a mask button
        self._maskButton = Button(self._buttonFrame,  text="Mask images", command=self.mask)
        self._maskButton.grid(column=1,  row=0,  sticky=[ 'e',  'w' ])
        #add a bones button
        self._bonesButton = Button(self._buttonFrame,  text="Open bones mask", command=lambda: self.open_mat_file(var_name='_bones'))
        self._bonesButton.grid(column=1,  row=1,  sticky=[ 'e',  'w' ])
        
        
        #3d column
        #add an open lesion file button 
        self._lesionButton = Button(self._buttonFrame,  text="Open lesion file", 
                                                    command=lambda: self.open_mat_file(var_name='_lesionImage',  action=self.open_lesion))
        self._lesionButton.grid(column=2,  row=0,  sticky=[ 'e',  'w' ])
        
        #add a save lesion file button 
        self._saveLesionButton = Button(self._buttonFrame,  text="Save lesion file", command=self.save_lesions)
        self._saveLesionButton.grid(column=2,  row=1,  sticky=[ 'e',  'w' ])
        
        #add a compute lesion button
        self._computeLesion = Button(self._buttonFrame,  text="Compute lesions from threshold", command=self.compute_lesions_from_threshold)
        self._computeLesion.grid(column=2,  row=2,  sticky=[ 'e',  'w' ])
        
        #4th column
        #add an open lymph node file button 
        self._openLymphButton = Button(self._buttonFrame,  text="Open lymph nodes file", 
                                                            command=lambda: self.open_mat_file(var_name='_lymphNode',  action=lambda: self.disp_im(which='CT')))
        self._openLymphButton.grid(column=3,  row=0,  sticky=[ 'e',  'w' ])
        
        #add an save lymph node file button 
        self._saveLymphButton = Button(self._buttonFrame,  text="Save lymph nodes file", command=self.save_lymph)
        self._saveLymphButton.grid(column=3,  row=1,  sticky=[ 'e',  'w' ])
        
       
        
        
    
    def reset_val(self):
        """reset all visualisation values to default"""
        self._image_size=(self._CTimage.size()[0],  self._CTimage.size()[1])
        self._zoom=0
        self._PETintensityScroll.reset( minVal=self._PETimage.min,  maxVal=self._PETimage.max)
        self._CTintensityScroll.reset( minVal=self._CTimage.min,  maxVal=self._CTimage.max)
        self._sliceScroll.reset(maxVal=self._CTimage.size()[2])
        self._lesionImage=None
        self._nb_positives=0
        self._nb_false_positives=0
        self._lymphNode=None
        self._bones = None
        self.disp_im(which='both')

    
    def open_CT(self):
        """used for opening a pair of PET/CT files
        all visualization values are reset to default and the images are replaced"""
        file=askopenfilename(title='Choose a CT file')
        pattern=re.compile('/')
        folder=file[:len(file)-pattern.search(file[::-1]).start()]
        file1=askopenfilename(title='Choose a PET file',  initialdir=folder)
        if len(file)>0 & len(file1)>0 :
            CT= Image(file)
            PET = Image(file1)
            if CT.size()==PET.size():
                self._CTimage=CT
                self._PETimage=PET
                self.reset_val()
                self._warninglabel["text"]=""
            else:
                self._warninglabel["text"]="Warning: All images should have the same size. Image not opened."
    
    def zoom_in(self,  *args):
        """modifies the zoom value and actualise the display"""
        self._zoom=self._zoom+10
        self._zoom=min(self._zoom,  math.floor(self._CTimage.size()[0]/2)-10,  math.floor(self._CTimage.size()[1]/2)-10)
        self.disp_im(which='both')
        
    def zoom_out(self,  *args):
        """modifies the zoom value and actualise the display"""
        self._zoom=self._zoom-10
        self._zoom=max(self._zoom,  0)
        self.disp_im(which='both')
        
    
    
    def convert_im(self, image,  maxInt,  slice):
        """get the image to display from a 3D Image"""
        if maxInt==0:
            maxInt=0.00001
        pix = numpy.array(image.slice_z(slice))
        pix=pix-pix.min()
        pix=pix[self._zoom:(pix.shape[0]-self._zoom),  self._zoom:(pix.shape[1]-self._zoom)]
        if pix.shape !=self._image_size: 
            return ImagePIL.fromarray(pix*255/maxInt).resize(self._image_size, ImagePIL.ANTIALIAS)
        else:
            return ImagePIL.fromarray(pix*255/maxInt)
    
    def superimpose_lesions(self, image,   slice):
        """superimpose in red the lesion image  if present (and the lymph nodes if present)onto *image*"""
        if (not (self._lesionImage is None)) | (not (self._lymphNode is None)):
            r,  g,  b=image.convert('RGB').split()
            if not (self._lesionImage is None):
                lesion_slice=self.convert_im(ImageW(img=numpy.array(self._lesionImage.img>0,  dtype='uint8')), 1,  slice)
                r=ImagePIL.fromarray(numpy.maximum(numpy.array(r), numpy.array(lesion_slice), dtype='uint8'),  mode='L')
                lesion_slice=self.convert_im(ImageW(img=numpy.array(self._lesionImage.img<0,  dtype='uint8')), 1,  slice)
                g=ImagePIL.fromarray(numpy.maximum(numpy.array(g), numpy.array(lesion_slice), dtype='uint8'),  mode='L')
            if not (self._lymphNode is None):
                lymph_slice=self.convert_im(ImageW(img=numpy.array(self._lymphNode.img>0,  dtype='uint8')), 1,  slice)
                b=ImagePIL.fromarray(numpy.maximum(numpy.array(b), numpy.array(lymph_slice), dtype='uint8'),  mode='L')
            return ImagePIL.merge("RGB", (r, g, b))
        else:
            return image
        
        
    def disp_im(self,  which='both'):
        """use the size, slice and zoom to display the images, only the image(s) given by *which* are actualised"""
        
        if (which=='both') | (which=='CT'):
            #CT with superimposed lesions if available
            temp_im=self.convert_im(self._CTimage, self._CTintensityScroll.val,  int(self._sliceScroll.val))
            self._curr_CTim = ImageTk.PhotoImage(self.superimpose_lesions(temp_im,  int(self._sliceScroll.val)))
            self._CTimagelabel['image']=self._curr_CTim
        if (which=='both') | (which=='PET'):
            #PET
            self._curr_PETim = ImageTk.PhotoImage(self.convert_im(self._PETimage, self._PETintensityScroll.val,  int(self._sliceScroll.val)))
            self._PETimagelabel['image']=self._curr_PETim
        #actualise slice label
        self._sliceLabelNumber['text']=str(int(self._sliceScroll.val)+1)
        
    def gotoslice(self):
        """moves to the desired slice"""
        
        z=self._newSlice.get()
        #if not an integer
        try:
            z=int(z)
            #if out of range
            if (z<0) | (z>self._CTimage.size()[2]):
                self._warninglabel['text']='Please enter a valid slice number'
            else:
                self._sliceScroll.set_value(z-1)
                self._newSlice.delete(0,  END)
                self._warninglabel['text']=''
        except ValueError:
            self._warninglabel['text']='Please enter a valid slice number'
        
    def resize(self,  event):  
        """handles the resizing of the image in case the window is resized"""
        self.update_idletasks()
        m=min(self._CTimagelabel.winfo_width(),  self._CTimagelabel.winfo_height())
        m=max(m, 3)
        self._image_size=(m-2, m-2)
        self.disp_im(which='both')
  
    def mask(self):
        """calls the *mask* function of the CT image to remove the background"""
        m=self._CTimage.mask()
        self._CTimage.img[m==0]=self._CTimage.min
        self._PETimage.img[m==0]=self._PETimage.min
        self.disp_im(which='both')
        
    def compute_lesions_from_threshold(self,  step=1):
        """checks if we want to save the current lesion image if exists and requires a threshold for computing the lesions by thresholding the PET image"""
        if step==1:
            if self._bones is None:
                self.disp_popup(msg='Please first open a bone file')
            else:
                if not (self._lesionImage is None):
                    self.disp_yes_no_popup(msg="Do you want to save the current lesions image", command_yes=self.save_lesions)
                self._popup_entry=Toplevel(self);
                self._popup_entry.geometry('+'+str(int(self.master.winfo_x()+self.master.winfo_width()/2))+'+'+str(int(self.master.winfo_y()+self.master.winfo_height()/2)))
                matMsg=Label(self._popup_entry,  text='Please enter a threshold to compute the lesions')
                matMsg.grid(column=0,  row=0)
                self._thEntry=Entry(self._popup_entry)
                self._thEntry.grid(column=0,  row=1)
                self._thEntry.bind('<Return>',  lambda event: self.compute_lesions_from_threshold(step=2))
                self._thEntry.bind('<KP_Enter>',  lambda event: self.compute_lesions_from_threshold(step=2))
                self.wait_window(self._popup_entry)
        else:
                th=self._thEntry.get()
                self._popup_entry.destroy()
                try:
                    th=float(th)
                    self._lesionImage=Image(img=((self._PETimage.img>th)&self._bones.img))
                    self.open_lesion()
                except ValueError:
                    self.disp_popup(msg='Please enter a valid threshold')
        
    def open_lesion(self):
        """actions to do when opening a lesion file"""
        label_im, nb_labels=ndimage.label(self._lesionImage.img>0)
        self._nb_positives=nb_labels
        self._nb_false_positives=0
        self._lesionImage =ImageW(img=label_im)
        self.disp_im(which='CT')
                    
    
    def open_mat_file(self, var_name, file='',  action=None,  msg='Choose a file'):
        """Used for opening a mat file."""
        if len(file)==0:
            file=askopenfilename(title=msg)
        if len(file)>0:
            if (file[(len(file)-4):(len(file))]=='.mat'):
                setattr(self, var_name,  ImageW(path))
                if getattr(self,  var_name).size()==self._CTimage.size():
                    self._warninglabel["text"]=""
                    if not (action is None):
                        action()
                    return 1
                else:
                    self._warninglabel["text"]="Warning: All images should have the same size. Mask not opened."
                    self[var_name] = None
                    return 0
            else:
                self.disp_popup(msg="Please choose a file with .mat extension")
                return 0
        else:
            return 0

    def check_lesion_image(self):
        """checks if a lesion image is present. If not, forbids the false positive category"""
        if self._lesionImage is None:
            if self.open_lesion()==0:
                self._selection.set(0)

    def select(self,   *args):
        """the function is called when the CT image is clicked. The action differs according to the value of *_selection* which is controlled by the radio buttons"""
        if self._selection.get()==0:
            print()
        elif self._selection.get()==1:
            self.update_idletasks()
            x=self._zoom+round((self._lesionImage.size()[1]-2*self._zoom)*(args[0].x-(self._CTimagelabel.winfo_width()-self._image_size[1])/2)/(self._image_size[1]))
            y=self._zoom+round((self._lesionImage.size()[0]-2*self._zoom)*(args[0].y-(self._CTimagelabel.winfo_height()-self._image_size[0])/2)/(self._image_size[0]))
            l=self._lesionImage.img[y, x, int(self._sliceScroll.val)]
            if (l>0):
                self._nb_false_positives=self._nb_false_positives+1
                self._lesionImage.img[self._lesionImage.img==l]=-self._nb_false_positives
                self.disp_im(which='CT')
        elif self._selection.get()==2:
            self.update_idletasks()
            #x=self._zoom+round((self._lesionImage.size()[1]-2*self._zoom)*args[0].x/(self._image_size[1]+2))
            #y=self._zoom+round((self._lesionImage.size()[0]-2*self._zoom)*args[0].y/(self._image_size[0]+2))
            x=self._zoom+round((self._lesionImage.size()[1]-2*self._zoom)*(args[0].x-(self._CTimagelabel.winfo_width()-self._image_size[1])/2)/(self._image_size[1]))
            y=self._zoom+round((self._lesionImage.size()[0]-2*self._zoom)*(args[0].y-(self._CTimagelabel.winfo_height()-self._image_size[0])/2)/(self._image_size[0]))
            l=self._lesionImage.img[y, x, int(self._sliceScroll.val)]
            if l<0:
                self._nb_positives=self._nb_positives+1
                self._lesionImage.img[self._lesionImage.img==l]=self._nb_positives
                self.disp_im(which='CT')
        elif self._selection.get()==3:
            self.update_idletasks()
            if self._lymphNode is None:
                self._lymphNode=ImageW(size=self._CTimage.size(),  value=0)
            x=self._zoom+round((self._lymphNode.size()[1]-2*self._zoom)*(args[0].x-(self._CTimagelabel.winfo_width()-self._image_size[1])/2)/(self._image_size[1]))
            y=self._zoom+round((self._lymphNode.size()[0]-2*self._zoom)*(args[0].y-(self._CTimagelabel.winfo_height()-self._image_size[0])/2)/(self._image_size[0]))
            self._lymphNode.img[y-3:y+3,  x-3:x+3, int(self._sliceScroll.val) ]=1
            self.disp_im(which='CT')

    def disp_yes_no_popup(self,  msg='',  command_yes=None,  command_no=None):
        """displays a popup with *msg* as text and three button.
        Since the application will wait on the popup, the commands of the button MUST destroy it"""
        self.update_idletasks()
        self._popup=Toplevel(self);
        self._popup.geometry('+'+str(int(self.master.winfo_x()+self.master.winfo_width()/2))+'+'+str(int(self.master.winfo_y()+self.master.winfo_height()/2)))
        saveMsg=Label(self._popup,  text=msg)
        saveMsg.grid(column=0,  row=0,  columnspan=3)
        if command_no is None:
            command_no=self._popup.destroy
        if command_yes is None:
            command_yes=self._popup.destroy
        noButton=Button(self._popup,  text="No", command=command_no)
        noButton.grid(column=0,  row=2,  sticky=[ 'e',  'w', 's',  'n' ])
        yesButton=Button(self._popup,  text="Yes", command=command_yes)
        yesButton.grid(column=1,  row=2,  sticky=[ 'e',  'w', 's',  'n' ])
        cancelButton=Button(self._popup,  text="Cancel", command=self._popup.destroy)
        cancelButton.grid(column=2,  row=2,  sticky=[ 'e',  'w', 's',  'n' ])
        self.wait_window(self._popup)
        
    def disp_popup(self,  msg=''):
        """displays a popup with *msg* as text and a button to close it"""
        self._popup_ok=Toplevel(self);
        self._popup_ok.geometry('+'+str(int(self.master.winfo_x()+self.master.winfo_width()/2))+'+'+str(int(self.master.winfo_y()+self.master.winfo_height()/2)))
        matMsg=Label(self._popup_ok,  text=msg)
        matMsg.grid(column=0,  row=0)
        okButton=Button(self._popup_ok,  text="Ok", command=self._popup_ok.destroy)
        okButton.grid(column=0,  row=1)
        self.wait_window(self._popup_ok)
        
    def save_files(self):
        """saves lesions and lymph nodes if exist then quit"""
        
        l1=1
        l2=1
        self._popup.destroy()
        if not(self._lymphNode is None):
            l1=self.save_lymph()
        if not (self._lesionImage is None):
            l2=self.save_lesions()
        if l1*l2>0:
            self.quit()
        
    def save_lesions(self ):
        """save the lesion image as true and false positive separate files if available"""
        
        if hasattr(self, '_popup'):
            self._popup.destroy()
        if self._lesionImage is None:
            self.dispPopup(msg='No lesions file opened')
            return 0
        else: 
            file=asksaveasfilename(title='Choose a file to save the lesion image',  filetypes=(('Mat files','*.mat'), ("All Files", "*.*")),  defaultextension='.mat')
            if len(file)>0:
                if (file[(len(file)-4):(len(file))]=='.mat'):
                    scipy.io.savemat(file,  {'lesions': self._lesionImage.img>0})
                    falsePos=self._lesionImage.img<0
                    if falsePos.sum(2).sum(1).sum(0)>0:
                        file=file[0:(len(file)-4)]+"_false_positives.mat"
                        scipy.io.savemat(file,  {'lesions': self._lesionImage.img<0})
                    return 1
                else:
                    self.dispPopup(msg="Please choose a file with .mat extension")
                    return 0
            else:
                return 0
  
    def save_lymph(self):
        """save the lymph nodes file"""
        if self._lymphNode is None:
            self._lymphNode=Image(size=self._CTimage.size(),  value=0)
        file=asksaveasfilename(title='Choose a file to save the lymph nodes image',  defaultextension='.mat',  filetypes=(('Mat files','*.mat'), ("All Files", "*.*")))
        if len(file)>0:
            if (file[(len(file)-4):(len(file))]=='.mat'):
                scipy.io.savemat(file,  {'lesions': self._lymphNode.img>0})
                return 1
            else:
                self.dispPopup(msg="Please choose a file with .mat extension")
                return 0
                
    def _quit(self):
        if hasattr(self, '_popup'):
            self._popup.destroy()
        if hasattr(self, '_popup_ok'):
            self._popup_ok.destroy()
        self.quit()
