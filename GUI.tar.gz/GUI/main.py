#Here, lauch the interface 
import sys
sys.path.append('/home/mbieth/Dropbox/TUM/Code/python/')
#import tempfile
#import urllib.request
import Tkinter

from ete2 import Tree 

from  GUI.Interface import *


if __name__ == "__main__":
    # Initialise main window of this application 
    root = Tkinter.Tk()
    root.title('Boundary box tool')
    
    # Initialise a few image paths
    test='/home/alberts/Documents/Data/30_MRI_GBM_patients/NIFTI/1/20131029/t1c_pre124.nii'
    test1='/home/alberts/Documents/Data/30_MRI_GBM_patients/NIFTI/1/20131029/flair_pre124.nii'
    # lesions='/home/mbieth/Data/Alpharadine/isotrop/Subject_17/04.2014/thresh_3/lesions.mat'
    # bones='/home/mbieth/Data/Alpharadine/isotrop/Subject_17/04.2014/thresh_3/bones.mat'
    image_path = '/home/alberts/Documents/Data/30_MRI_GBM_patients/NIFTI/1/20131029/flair_pre124.nii'
    
    
    # Run the application
    inter = Interface(root,image_path)
    root.mainloop()
    
    print inter._minCo, inter._maxCo

def select_boundaries(filename):
    
    root = Tkinter.Tk()
    root.title('Annotation tool')
    
    inter = Interface(root, filename)
    root.mainloop()
    root.destroy()
    print inter._minCo, inter._maxCo
    return inter._minCo, inter._maxCo

def select_boundaries_plural(filenames):

    lower_boundaries = []
    upper_boundaries = []
    
    for i in range(len(filenames)):
        
        tlc, tuc = select_boundaries(filenames[i])
        
        lower_boundaries.append(np.array(tlc))
        upper_boundaries.append(np.array(tuc))
    
    return lower_boundaries, upper_boundaries