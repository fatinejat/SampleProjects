m12 = [[1, 1, 1]; [2, 2, 1]; [3, 1, 0]];
figure;
gscatter(m12(:,1), m12(:,2), m12(:,3), 'br', 'xo')
xlabel('climate');
ylabel('housing');