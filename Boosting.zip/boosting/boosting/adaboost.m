n = 1000;   % number of data points
T = 100;    % number of iterations

% Generate the training and testing set
[X_train, Y_train] = generate_data(n);
[X_test, Y_test] = generate_data(n);

% Strong classifier
F_train = zeros(n,1);   % evaluated on the training set
F_test = zeros(n,1);    % evaluated on the testing set

% Training and testing errors
error_train = zeros(T,1);
error_test = zeros(T,1);

% Initialization of the weights
W = ones(n,1) / n;

for i=1:T
    % Weak classifier optimization
    [d, t, polarity] = best_stump(X_train, Y_train, W);
    % Evaluation of the weak classifier
    f = polarity * (2*(X_train(:,d) > t) - 1);
    
    % compute e
    e = (W' * (Y_train ~= f)) / sum(W);
    
    % compute alpha
    alpha = 0.5 * log((1-e)/e);
    
    % compute Z
    aux = exp(-alpha * (Y_train .* f));
    Z = W' * aux;
    
    % update the weights
    W = W/Z .* aux;
    
    % Update the strong classifier and compute the error
    F_train = F_train + alpha * f;
    error_train(i) = sum(Y_train.*F_train<0) / length(Y_train);
    
    % Same for the test data
    f = polarity * (2*(X_test(:,d) > t) - 1);
    F_test = F_test + alpha * f;
    error_test(i) = sum(Y_test.*F_test<0) / length(Y_test);
end

figure;
subplot(3,1,1);
gscatter(X_test(:,1),X_test(:,2),Y_test,'br','oo')
xlabel('X1');
ylabel('X2');
title('True values')

subplot(3,1,2);
gscatter(X_test(:,1),X_test(:,2),sign(F_test),'br','oo')
xlabel('X1');
ylabel('X2');
title('Predictions');

subplot(3,1,3);
plot(1:100,error_train,'-',1:100,error_test, '-' );
legend('Training error','Testing error');
title('Training error vs. testing error');

