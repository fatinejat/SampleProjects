D = csvread('data3.csv');

% can be ran multiple times with different initializations and consider the
% restult of the run which maximizes the loglokelihood
y = randsample(size(D,2),2);
[data, parameters, steps, llh1] = EM(D,2, y, false);

fprintf('First gaussian has mu = ');
parameters(1).mu
fprintf('First gaussian has sigma = ');
parameters(1).sigma
fprintf('Second gaussian has mu = ');
parameters(2).mu
fprintf('Second gaussian has sigma = ');
parameters(2).sigma
% if the data is the result of pca, the variables shoul be uncorelated,
% therefore the initial cov matrix will only have non-zero values on the
% diagonal

[data2, parameters2, steps2, llh2] = EM(D,2, y, true);

fprintf('PCA First gaussian has mu = ');
parameters2(1).mu
fprintf('PCA First gaussian has sigma = ');
parameters2(1).sigma
fprintf('PCA Second gaussian has mu = ');
parameters2(2).mu
fprintf('PCA Second gaussian has sigma = ');
parameters2(2).sigma

% As a general observation, after a few runs, if seems that running EM with the
% assumtion that the data is the result of PCA
% will converge faster than without this assumption. Also, the difference between the 
% likelihhoods are minimal
fprintf('Without PCA: Converged in %d steps\n', steps);
fprintf('With PCA: Converged in %d steps \n', steps2);

fprintf('Likelihood without PCA %d \n', llh1);
fprintf('Likelihood with PCA %d \n', llh2);
