function [ data ] = KMedoids( D, k )
% D - dissimilarity matrix
% k - number of clusters

N = size(D,1);
actual_medoids = zeros(k,1);
next_medoids = zeros(k,1);

% cluster - the cluster of the data point
% cost - the cost of the data point i to become a medoid
data = repmat(struct('cluster',1,'cost',1),N,1);

%initialization of k medoids
y = randsample(N,k);
for i=1:k
    data(y(i)).cluster = i;
    actual_medoids(i) = y(i);
end

%k-medoids algorithm
while (medoidsChanged(actual_medoids, next_medoids, k))
    if(~isequal(next_medoids,zeros(k,1)))
        actual_medoids = next_medoids;
    end
    
    %assign data points to clusters
    for i = 1:N
        data(i).cluster = getCluster (D,i,actual_medoids);
    end
    
    min_costs = 1000 * ones(k,1);
    for i = 1:N
        data(i).cost = getCost(data, i, D);
        if(min_costs(data(i).cluster,1) > data(i).cost)
            min_costs(data(i).cluster,1) = data(i).cost;
            next_medoids(data(i).cluster) = i;
        end
    end
end

end

function [change] = medoidsChanged(actual_medoids, next_medoids, k)

change = false;
for i=1:k
    if (actual_medoids(i) ~= next_medoids(i))
        change = true;
        break;
    end
end

end

function [cluster] = getCluster (D,i,actual_medoids)
min_dissim = 1000;
for k = 1:size(actual_medoids,1)
    dissim = D(i,actual_medoids(k));
    if(min_dissim > dissim)
        min_dissim = dissim;
        cluster = k;
    end
end
end

function [cost] = getCost (data, new_medoid, D)
cost = 0;
no_points = 0;
for j = 1:size(D,1)
    if(data(j).cluster == data(new_medoid).cluster)
        cost = cost + D(j,new_medoid);% if j = new_medoid , D(j,new_medoid) = 0
        no_points = no_points + 1;
    end
end
cost = cost / (no_points - 1); % subtracting the point itself(new_medoid)
end

