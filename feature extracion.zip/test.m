function [] = test
file = load('data_1.mat')
lbp(integral_image(file.MR,17),17)
end

