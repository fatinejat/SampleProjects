function [ integral_img ] = integral_image(img ,a) 
%before creating the integral image we need to extend the border of the
%image matrix so we can safely compute the mean_patch => we need to add a
%border of size (a-1)/2+1
    dim = size(img);
    extended_img = extend(img,a);

    integral_dim = [dim(1)+a, dim(2)+a];
    integral_img = zeros(integral_dim);

    for i=2:integral_dim(1)
        for j=2:integral_dim(2)
            integral_img(i,j) = extended_img(i-1,j-1)+integral_img(i-1,j)+integral_img(i,j-1)-integral_img(i-1,j-1);
        end;
    end;
end

function [ext_I] = extend(I, a)
dim_I = size(I);
% surround I with (a + (a-1)/2) lines and columns of 0
ext = (a+1)/2;
ext_I = zeros(dim_I(1)+2*ext, dim_I(2)+2*ext);
ext_I(ext + 1: ext+dim_I(1),ext + 1: ext+dim_I(2)) = I;
end

