function [mean_of_int] = mean_patch(I, a, alpha, beta)

offset = (a-1)/2; %size a must be odd    
% y1,y2,x1,x2 must be within the border of the integral(extended) image
y1 = alpha - offset;
y2 = alpha + offset;

x1 = beta - offset;
x2 = beta + offset;

sum = I(y2+1,x2+1) - I(y2+1,x1) - I(y1,x2+1) + I(y1,x1);

mean_of_int = sum/ (a^2);

end

