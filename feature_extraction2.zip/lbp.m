function [ x ] = lbp(I,a)
mean_feat_vect = mean_features(I,a);
dim = size(mean_feat_vect);

x = zeros(dim(1),dim(2), dim(3)-1);

for i=1:dim(1)
    for j= 1:dim(2) 
        for k=1:dim(3)
            if(k~=5)
                if(mean_feat_vect(i,j,k) >= mean_feat_vect(i,j,5))
                    x(i,j,get_index(k)) = 1;
                else
                    x(i,j,get_index(k)) = 0;
                end
            end
        end
    end
end

end

function [index] = get_index(k)
    if(k > 5)
        index = k - 1;
    else
        index = k;
    end
end


