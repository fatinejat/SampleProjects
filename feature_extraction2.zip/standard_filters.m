function [ X ] = standard_filters( img, F, a, std_dev )
if(strcmp(F, 'straight derivatives')==0)
    dim = size(img);
    A=zeros(dim(1)+4, dim(2)+4); %zero border for img
    A(2:dim(1),2:dim(2))=img;
    h=
    filter2(g, I, 'same');
elseif (strcmp(F, 'diagonal derivatives')==0)
elseif (strcmp(F, 'mean')==0)
elseif (strcmp(F, 'std')==0)
elseif (strcmp(F, 'gaussian')==0)
elseif (strcmp(F, 'LoG')==0)
elseif (strcmp(F, 'all')==0)
end

        
    


end

