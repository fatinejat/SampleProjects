function [mean_feat_vect] = mean_features(I, a)
%I is the integral(extended) image
dim = size(I);
dim1 = dim(1)-a;
dim2 = dim(2)-a;

mean_feat_vect = zeros (dim1, dim2, 9);
border = (a-1)/2 + 1;

for i=1:dim1
    for j= 1: dim2     
        mean_feat_vect(i,j,1) = mean_patch_or_zero(I,a,i+border-a,j+border-a);
        mean_feat_vect(i,j,2) = mean_patch_or_zero(I,a,i+border-a,j+border);
        mean_feat_vect(i,j,3) = mean_patch_or_zero(I,a,i+border-a,j+border+a);
        mean_feat_vect(i,j,4) = mean_patch_or_zero(I,a,i+border,j+border-a);
        mean_feat_vect(i,j,5) = mean_patch_or_zero(I,a,i+border,j+border);
        mean_feat_vect(i,j,6) = mean_patch_or_zero(I,a,i+border,j+border+a);
        mean_feat_vect(i,j,7) = mean_patch_or_zero(I,a,i+border+a,j+border-a);
        mean_feat_vect(i,j,8) = mean_patch_or_zero(I,a,i+border+a,j+border);
        mean_feat_vect(i,j,9) = mean_patch_or_zero(I,a,i+border+a,j+border+a);
    end
end


end

function[mean] = mean_patch_or_zero(I,a,alpha, beta)
    dim = size(I);
    if(alpha <= (a+1)/2 || beta <= (a+1)/2 || alpha > dim(1)-((a+1)/2) || beta > dim(2)-((a+1)/2))
        mean = 0;
    else
        mean = mean_patch(I,a,alpha,beta);
    end
    
end

