function [ x ] = long_range_two_offsets(I, a, w1, w2 )
  %I is the integral(extended) image - we need to remove the border
  dim = size(I);
  dim(1) = dim(1)-a;
  dim(2) = dim(2)-a;
  
  x = zeros(dim(1), dim(2), 2);
  
  for i=1:dim(1)
    for j= 1:dim(2) 
        x(i,j,1) = mean(I,a,i+w1(1),j+w1(2)) - mean(I,a,i+w2(1),j+w2(2));
        if(x(i,j,1) >= 0)
            x(i,j,2) = 1;
        else
            x(i,j,2) = 0;
        end
     end
  end
end

