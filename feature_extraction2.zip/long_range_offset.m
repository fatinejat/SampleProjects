function [ x ] = long_range_offset(I,a,w)

  mean_feat_vect = mean_features(I,a);
  dim = size(mean_feat_vect);

  x = zeros(dim(1), dim(2), 2);
  
  for i=1:dim(1)
    for j= 1:dim(2) 
        x(i,j,1) = mean(I,a,i+w(1),j+w(2)) - mean_feat_vect(i,j,5);
        if(x(i,j,1) >= 0)
            x(i,j,2) = 1;
        else
            x(i,j,2) = 0;
        end
     end
  end
end

